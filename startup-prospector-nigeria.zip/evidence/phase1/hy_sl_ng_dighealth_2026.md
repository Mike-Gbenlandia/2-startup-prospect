[Skip to content](https://www.startuplist.africa/fundings/nigeria/digital-health/2026#main-content)

Live market

NGX ASI245,685.87-0.32%

JSE TOP40105,663.54-0.26%

NGX ASI245,685.87-0.32%

JSE TOP40105,663.54-0.26%

NGX ASI245,685.87-0.32%

JSE TOP40105,663.54-0.26%

NGX ASI245,685.87-0.32%

JSE TOP40105,663.54-0.26%

Updated **24 Nov 2026****7,030 rounds tracked**Source: **SLA Funding Index** [How we count →](https://www.startuplist.africa/methodology) [Submit a round →](https://www.startuplist.africa/submit-startup)

Year · 2026▾

- [All years](https://www.startuplist.africa/fundings/nigeria/digital-health)
- [2026](https://www.startuplist.africa/fundings/nigeria/digital-health/2026)
- [2025](https://www.startuplist.africa/fundings/nigeria/digital-health/2025)
- [2024](https://www.startuplist.africa/fundings/nigeria/digital-health/2024)
- [2023](https://www.startuplist.africa/fundings/nigeria/digital-health/2023)
- [2022](https://www.startuplist.africa/fundings/nigeria/digital-health/2022)
- [2021](https://www.startuplist.africa/fundings/nigeria/digital-health/2021)
- [2020](https://www.startuplist.africa/fundings/nigeria/digital-health/2020)
- [2019](https://www.startuplist.africa/fundings/nigeria/digital-health/2019)
- [2018](https://www.startuplist.africa/fundings/nigeria/digital-health/2018)
- [2017](https://www.startuplist.africa/fundings/nigeria/digital-health/2017)
- [2016](https://www.startuplist.africa/fundings/nigeria/digital-health/2016)
- [2015](https://www.startuplist.africa/fundings/nigeria/digital-health/2015)

[×](https://www.startuplist.africa/fundings/nigeria/digital-health)

Round▾

- [Seed](https://www.startuplist.africa/fundings/nigeria/digital-health/seed/2026)
- [Pre-seed](https://www.startuplist.africa/fundings/nigeria/digital-health/pre-seed/2026)
- [Grant](https://www.startuplist.africa/fundings/nigeria/digital-health/grant/2026)
- [Venture](https://www.startuplist.africa/fundings/nigeria/digital-health/venture/2026)
- [Debt Financing](https://www.startuplist.africa/fundings/nigeria/digital-health/debt-financing/2026)
- [Series A](https://www.startuplist.africa/fundings/nigeria/digital-health/series-a/2026)
- [Non-equity Assistance](https://www.startuplist.africa/fundings/nigeria/digital-health/non-equity-assistance/2026)
- [Funding Round](https://www.startuplist.africa/fundings/nigeria/digital-health/funding-round/2026)
- [Series B](https://www.startuplist.africa/fundings/nigeria/digital-health/series-b/2026)
- [Angel](https://www.startuplist.africa/fundings/nigeria/digital-health/angel/2026)
- [Private Equity](https://www.startuplist.africa/fundings/nigeria/digital-health/private-equity/2026)
- [Convertible Note](https://www.startuplist.africa/fundings/nigeria/digital-health/convertible-note/2026)
- [Series C](https://www.startuplist.africa/fundings/nigeria/digital-health/series-c/2026)
- [Corporate](https://www.startuplist.africa/fundings/nigeria/digital-health/corporate/2026)
- [Equity Crowdfunding](https://www.startuplist.africa/fundings/nigeria/digital-health/equity-crowdfunding/2026)
- [Undisclosed](https://www.startuplist.africa/fundings/nigeria/digital-health/undisclosed/2026)
- [Post-IPO Equity](https://www.startuplist.africa/fundings/nigeria/digital-health/post-ipo-equity/2026)
- [Series D](https://www.startuplist.africa/fundings/nigeria/digital-health/series-d/2026)
- [Pre-Series A](https://www.startuplist.africa/fundings/nigeria/digital-health/pre-series-a/2026)
- [Investment (round not specified)](https://www.startuplist.africa/fundings/nigeria/digital-health/investment-round-not-specified/2026)
- [EmFi Series](https://www.startuplist.africa/fundings/nigeria/digital-health/emfi-series/2026)
- [Equity-free prize](https://www.startuplist.africa/fundings/nigeria/digital-health/equity-free-prize/2026)
- [Post-IPO Debt](https://www.startuplist.africa/fundings/nigeria/digital-health/post-ipo-debt/2026)
- [Equity investment](https://www.startuplist.africa/fundings/nigeria/digital-health/equity-investment/2026)
- [Accelerator](https://www.startuplist.africa/fundings/nigeria/digital-health/accelerator/2026)
- [Equity](https://www.startuplist.africa/fundings/nigeria/digital-health/equity/2026)
- [Series E](https://www.startuplist.africa/fundings/nigeria/digital-health/series-e/2026)
- [Secondary Market](https://www.startuplist.africa/fundings/nigeria/digital-health/secondary-market/2026)
- [Undisclosed investment](https://www.startuplist.africa/fundings/nigeria/digital-health/undisclosed-investment/2026)
- [Pre-Series B](https://www.startuplist.africa/fundings/nigeria/digital-health/pre-series-b/2026)

Country · Nigeria▾

- [Nigeria](https://www.startuplist.africa/fundings/nigeria/digital-health/2026)
- [Kenya](https://www.startuplist.africa/fundings/kenya/digital-health/2026)
- [Egypt](https://www.startuplist.africa/fundings/egypt/digital-health/2026)
- [South Africa](https://www.startuplist.africa/fundings/south-africa/digital-health/2026)
- [Ghana](https://www.startuplist.africa/fundings/ghana/digital-health/2026)
- [Morocco](https://www.startuplist.africa/fundings/morocco/digital-health/2026)
- [Uganda](https://www.startuplist.africa/fundings/uganda/digital-health/2026)
- [Rwanda](https://www.startuplist.africa/fundings/rwanda/digital-health/2026)
- [Tunisia](https://www.startuplist.africa/fundings/tunisia/digital-health/2026)
- [Côte d'Ivoire](https://www.startuplist.africa/fundings/cote-divoire/digital-health/2026)
- [Senegal](https://www.startuplist.africa/fundings/senegal/digital-health/2026)
- [Tanzania](https://www.startuplist.africa/fundings/tanzania/digital-health/2026)
- [Mauritius](https://www.startuplist.africa/fundings/mauritius/digital-health/2026)
- [Zambia](https://www.startuplist.africa/fundings/zambia/digital-health/2026)
- [Ethiopia](https://www.startuplist.africa/fundings/ethiopia/digital-health/2026)
- [DR Congo](https://www.startuplist.africa/fundings/dr-congo/digital-health/2026)
- [Cameroon](https://www.startuplist.africa/fundings/cameroon/digital-health/2026)
- [Algeria](https://www.startuplist.africa/fundings/algeria/digital-health/2026)
- [Mali](https://www.startuplist.africa/fundings/mali/digital-health/2026)
- [Zimbabwe](https://www.startuplist.africa/fundings/zimbabwe/digital-health/2026)
- [Togo](https://www.startuplist.africa/fundings/togo/digital-health/2026)
- [Angola](https://www.startuplist.africa/fundings/angola/digital-health/2026)
- [Sierra Leone](https://www.startuplist.africa/fundings/sierra-leone/digital-health/2026)
- [Malawi](https://www.startuplist.africa/fundings/malawi/digital-health/2026)
- [Somalia](https://www.startuplist.africa/fundings/somalia/digital-health/2026)
- [Mozambique](https://www.startuplist.africa/fundings/mozambique/digital-health/2026)
- [Guinea](https://www.startuplist.africa/fundings/guinea/digital-health/2026)
- [Burkina Faso](https://www.startuplist.africa/fundings/burkina-faso/digital-health/2026)
- [Benin](https://www.startuplist.africa/fundings/benin/digital-health/2026)
- [Lesotho](https://www.startuplist.africa/fundings/lesotho/digital-health/2026)
- [Sudan](https://www.startuplist.africa/fundings/sudan/digital-health/2026)
- [Namibia](https://www.startuplist.africa/fundings/namibia/digital-health/2026)
- [Seychelles](https://www.startuplist.africa/fundings/seychelles/digital-health/2026)
- [Botswana](https://www.startuplist.africa/fundings/botswana/digital-health/2026)
- [Libya](https://www.startuplist.africa/fundings/libya/digital-health/2026)
- [Madagascar](https://www.startuplist.africa/fundings/madagascar/digital-health/2026)
- [Liberia](https://www.startuplist.africa/fundings/liberia/digital-health/2026)
- [Congo](https://www.startuplist.africa/fundings/congo/digital-health/2026)
- [Gabon](https://www.startuplist.africa/fundings/gabon/digital-health/2026)
- [Côte D'ivoire](https://www.startuplist.africa/fundings/cote-divoire/digital-health/2026)
- [Niger](https://www.startuplist.africa/fundings/niger/digital-health/2026)
- [Mauritania](https://www.startuplist.africa/fundings/mauritania/digital-health/2026)
- [Eswatini](https://www.startuplist.africa/fundings/eswatini/digital-health/2026)
- [Djibouti](https://www.startuplist.africa/fundings/djibouti/digital-health/2026)

[×](https://www.startuplist.africa/fundings/digital-health/2026)

Sector · Digital Health▾

- [Financial Services](https://www.startuplist.africa/fundings/nigeria/financial-services/2026)
- [Health Care](https://www.startuplist.africa/fundings/nigeria/health-care/2026)
- [FinTech](https://www.startuplist.africa/fundings/nigeria/fintech/2026)
- [E-Commerce](https://www.startuplist.africa/fundings/nigeria/e-commerce/2026)
- [AgriTech](https://www.startuplist.africa/fundings/nigeria/agritech/2026)
- [Energy](https://www.startuplist.africa/fundings/nigeria/energy/2026)
- [Agriculture](https://www.startuplist.africa/fundings/nigeria/agriculture/2026)
- [EdTech](https://www.startuplist.africa/fundings/nigeria/edtech/2026)
- [Transportation](https://www.startuplist.africa/fundings/nigeria/transportation/2026)
- [Logistics](https://www.startuplist.africa/fundings/nigeria/logistics/2026)
- [Education](https://www.startuplist.africa/fundings/nigeria/education/2026)
- [Information Technology Services](https://www.startuplist.africa/fundings/nigeria/information-technology-services/2026)
- [Renewable Energy](https://www.startuplist.africa/fundings/nigeria/renewable-energy/2026)
- [Artificial Intelligence](https://www.startuplist.africa/fundings/nigeria/artificial-intelligence/2026)
- [SaaS](https://www.startuplist.africa/fundings/nigeria/saas/2026)
- [Banking](https://www.startuplist.africa/fundings/nigeria/banking/2026)
- [Manufacturing](https://www.startuplist.africa/fundings/nigeria/manufacturing/2026)
- [Marketplace](https://www.startuplist.africa/fundings/nigeria/marketplace/2026)
- [Finance](https://www.startuplist.africa/fundings/nigeria/finance/2026)
- [Insurance](https://www.startuplist.africa/fundings/nigeria/insurance/2026)
- [Automotive](https://www.startuplist.africa/fundings/nigeria/automotive/2026)
- [Advertising](https://www.startuplist.africa/fundings/nigeria/advertising/2026)
- [Human Resources](https://www.startuplist.africa/fundings/nigeria/human-resources/2026)
- [Software](https://www.startuplist.africa/fundings/nigeria/software/2026)
- [Biotechnology](https://www.startuplist.africa/fundings/nigeria/biotechnology/2026)
- [Information Technology](https://www.startuplist.africa/fundings/nigeria/information-technology/2026)
- [Health](https://www.startuplist.africa/fundings/nigeria/health/2026)
- [Big Data](https://www.startuplist.africa/fundings/nigeria/big-data/2026)
- [Electric Mobility](https://www.startuplist.africa/fundings/nigeria/electric-mobility/2026)
- [HealthTech](https://www.startuplist.africa/fundings/nigeria/healthtech/2026)
- [Gaming](https://www.startuplist.africa/fundings/nigeria/gaming/2026)
- [Payments](https://www.startuplist.africa/fundings/nigeria/payments/2026)
- [Food and Beverage](https://www.startuplist.africa/fundings/nigeria/food-and-beverage/2026)
- [PropTech](https://www.startuplist.africa/fundings/nigeria/proptech/2026)
- [Consumer Goods](https://www.startuplist.africa/fundings/nigeria/consumer-goods/2026)
- [E-Learning](https://www.startuplist.africa/fundings/nigeria/e-learning/2026)
- [InsurTech](https://www.startuplist.africa/fundings/nigeria/insurtech/2026)
- [Digital Health](https://www.startuplist.africa/fundings/nigeria/digital-health/2026)
- [Blockchain](https://www.startuplist.africa/fundings/nigeria/blockchain/2026)
- [Retail](https://www.startuplist.africa/fundings/nigeria/retail/2026)

[×](https://www.startuplist.africa/fundings/nigeria/2026)

Size▾

- [Undisclosed](https://www.startuplist.africa/fundings/nigeria/digital-health/2026?bucket=undisclosed)
- [Under $1M](https://www.startuplist.africa/fundings/nigeria/digital-health/2026?bucket=under-1m)
- [$1M – $5M](https://www.startuplist.africa/fundings/nigeria/digital-health/2026?bucket=1m-5m)
- [$5M – $20M](https://www.startuplist.africa/fundings/nigeria/digital-health/2026?bucket=5m-20m)
- [$20M – $50M](https://www.startuplist.africa/fundings/nigeria/digital-health/2026?bucket=20m-50m)
- [$50M+](https://www.startuplist.africa/fundings/nigeria/digital-health/2026?bucket=50m-plus)

2 rounds · 2026 · Nigeria · Digital Health

## Digital Health startup funding in Nigeria, 20262 · newest first

[All 7,030 rounds →](https://www.startuplist.africa/fundings)

| # | Startup | Round | HQ | Investors | Amount | Date |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | ![](https://www.startuplist.africa/_next/image?url=https%3A%2F%2Fs3.amazonaws.com%2Fstartuplist.africa%2Fstartups%2Fmariam-grey-pharmacy%2Fd7c26b47-0ac1-445c-9dea-eb9b08ad888e.png&w=64&q=75)<br>[Mariam Grey Pharmacy](https://www.startuplist.africa/startups/mariam-grey-pharmacy) HealthTechGrant · Nigeria | [Grant](https://www.startuplist.africa/funding/mariam-grey-pharmacy-grant-10k-usd-dc37247) | Nigeria | [Standard Chartered Foundation](https://www.startuplist.africa/investors/standard-chartered-foundation) | $10K03 Oct | 03 Oct |
| 2 | ![](https://www.startuplist.africa/_next/image?url=https%3A%2F%2Fs3.amazonaws.com%2Fstartuplist.africa%2Fstartups%2Fmobihealth-international%2Fmobihealth-international-logo.jpg&w=64&q=75)<br>[Mobihealth International](https://www.startuplist.africa/startups/mobihealth-international) Telemedicine · LagosVenture · Nigeria | [Venture](https://www.startuplist.africa/funding/mobihealth-international-venture-674k-usd-3191e7a) | Nigeria | [SCM Capital](https://www.startuplist.africa/investors/scm-capital) | $741K11 Feb | 11 Feb |

SLA Funding Index · as of 25 Nov 2026

## Questions about Digital Health startup funding in Nigeria, 2026

How many funding rounds did Digital Health startups in Nigeria raise in 2026?StartupList Africa tracks 2 rounds in this view as of 25 Nov 2026, listed newest first.

How often is funding data updated?Our funding database is updated daily. We track disclosed rounds from press releases, regulatory filings, investor announcements, and verified startup submissions.

What funding stages are tracked?We track all stages including Pre-Seed, Seed, Series A through Series E+, as well as alternative capital types like angel investments, grants, debt financing, and convertible notes.

How is the funding amount determined?Amounts shown are the disclosed USD equivalent at the time of announcement. Where the round was denominated in local currency, we convert using the exchange rate on the announcement date.