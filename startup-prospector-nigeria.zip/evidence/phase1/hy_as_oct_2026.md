[Skip to main content](https://african-startups.com/news/funding/meet-the-african-startups-that-secured-funding-in-october-2026/#brx-content) [Skip to footer](https://african-startups.com/news/funding/meet-the-african-startups-that-secured-funding-in-october-2026/#brx-footer)

[Africa](https://african-startups.com/category/countries/africa/), [Funding](https://african-startups.com/category/news/funding/), [Lists](https://african-startups.com/category/lists/)

October 30, 2026

# Meet the African startups that secured funding in October 2026

This month, the deals landed across Egypt, Nigeria, South Africa, Kenya, Tanzania, Rwanda, Ghana, Senegal, Morocco, Ethiopia, Angola, Zambia, Uganda, Cameroon, and beyond. Here are the African companies that secured funding in October 2026.

![](https://secure.gravatar.com/avatar/5f51db54bca424be86be2832e562dc49c3975191238f309b56c8a8592f14699a?s=36&d=mm&r=g)

## Rahul Raj

Author

Copy link to article

![](https://african-startups.com/wp-content/uploads/2026/10/Meet-the-African-startups-that-secured-funding-in-October-2026-1024x683.jpg)

_Editor’s note: [**African-Startups**](http://african-startups.com/) is a sister publication of [**EU-Startups**](https://www.eu-startups.com/), bringing trusted coverage of startups, venture capital, and innovation across Africa._

In October 2026, African startups raised capital across a wide range of sectors, with climate and clean-energy deals leading the headlines alongside notable fintech, agritech, logistics, mobility, and healthtech raises.

According to [**Disrupt Africa**](https://disruptafrica.com/2026/10/05/58-african-tech-startups-raise-583m-in-funding-in-q3/), 58 African tech startups raised close to $583 million in Q3 2026, the strongest quarter of the year and roughly 70% more than the $342.2 million raised in the same period of 2025.

In the first nine months of 2026, 137 startups raised about $1.39 billion. If this trend continues, the year could see around 182 funded startups and $1.85 billion in total funding, surpassing the $1.6 billion raised in 2025.

Initially, the funding outlook was unclear. In Q1 2026, startups raised $382.15 million from 40 companies, reflecting a 35% increase from the previous year.

However, Q2 saw a drop to $260 million from 38 startups, raising concerns about a potential decline. Fortunately, Q3 improved, and October’s activity suggests the positive trend is likely continuing into Q4, the report says.

In October 2026, the deals cover a wide range of African venture activities, from small pre-Seed investments for new founders to large debt financing for established companies in energy and mobility.

Many of these rounds combine equity, debt, and grants, reflecting a trend of startups using multiple funding methods to support climate and infrastructure projects.

This month, the deals landed across Egypt, Nigeria, South Africa, Kenya, Tanzania, Rwanda, Ghana, Senegal, Morocco, Ethiopia, Angola, Zambia, Uganda, Cameroon, and beyond. Here are the African companies that secured funding in October 2026.

## Prometal SA

**HQ**: Cameroon

**CEO:** Hayssam El Jammal

**Funding raised in Oct 2026:** [**$45.6 million revolving working capital facility from Afreximbank**](https://african-startups.com/countries/cameroon/cameroons-prometal-sa-gets-45-6-million-working-capital-facility-from-afreximbank/)

Prometal SA is a Cameroonian metallurgical and industrial conglomerate built around two divisions: Prometal Acier, its core steel and metallurgical arm operating seven industrial plants with roughly 360,000 metric tons of annual finished-steel capacity, and NOVIA Industries, an agribusiness venture launched in 2018 with capacity for about 500 tons of edible oil and 160 tons of soap per day. The group supplies construction, infrastructure, industrial, and agricultural end markets.

## Ororo Waste Management Limited

**HQ**: Nigeria

**Founded year:** 2021

**Founder(s):** Ayodele Banjo and Lawson Nzekwe

**Funding raised in Oct 2026:** [**Up to $1 million investment from Rising Tide Africa**](https://african-startups.com/countries/nigeria/nigerias-ororo-waste-secures-up-to-1-million-from-rising-tide-africa-to-expand-used-cooking-oil-collection/)

Ororo Waste Management collects used cooking oil from households, markets, and businesses across Nigeria and channels it into waste-based feedstock markets. The company operates three collection hubs in Lagos, Abuja, and Port Harcourt, and serves as Lagos State’s partner for institutional-scale used cooking oil collection and export. Its paid collector network currently stands at around 5,000 people, with a target of exceeding 200,000 collectors and 150,000 tonnes of certified annual collection by 2031.

## Cold Solutions Rwanda

**HQ**: Rwanda

**Funding raised in Oct 2026:** [**Up to $18 million senior debt facility from the Africa Go Green Fund**](https://african-startups.com/countries/rwanda/cold-solutions-rwanda-secures-up-to-18-million-from-africa-go-green-fund-for-kigali-cold-storage-facility/)

Cold Solutions Rwanda Limited is developing and operating a modern cold storage facility in the Kigali Prime Economic Zone, positioning itself as critical infrastructure for Rwanda’s cold-chain logistics. The initial build will offer 4,000 pallet positions, with capacity expandable to 8,000 pallets as demand grows. The facility is designed to reduce post-harvest food losses, support agricultural exports, and strengthen the country’s broader logistics ecosystem.

## Prado Power

**HQ**: Nigeria

**Funding raised in Oct 2026:** [**Senior debt facility from REPP 2, managed by Camco**](https://african-startups.com/countries/nigeria/nigerias-prado-power-secures-repp-2-debt-financing-to-develop-five-solar-mini-grids-with-battery-storage/)

Prado Power is an Abuja-based renewable energy developer that designs and operates off-grid solar mini-grids paired with battery storage, delivering first-time electricity to underserved rural communities in Nigeria. With the senior debt facility from the Renewable Energy Performance Platform 2, backed by the Green Climate Fund, Norfund, FMO, BIO, OeEB, and Ceniarth, the company will build five solar mini-grid sites across Benue and Nasarawa states totaling 1.84 MWp of solar PV capacity and 5.2 MWh of battery storage. The projects aim to connect more than 12,000 households and MSMEs, enabling productive uses such as agro-processing and cold storage, while displacing costlier diesel generation.

## Satlyt

**HQ:** Kenya

**CEO:** Rama Afullo

**Funding raised in Oct 2026:** [**$8 million Seed round led by Non Sibi Ventures**](https://african-startups.com/news/funding/nairobi-and-sunnyvale-based-satlyt-raises-8-million-to-build-the-intelligence-layer-for-satellites/)

Satlyt is a space-technology startup building what it calls the intelligence layer for satellites, a software that runs AI and data processing directly onboard orbiting spacecraft, allowing operators to downlink actionable insights rather than massive raw data files. The company is dual-headquartered in Sunnyvale, California, and Nairobi, Kenya, where a large share of its engineering team sits, and has signed memoranda of understanding with the Kenya Space Agency and Angola’s GGPEN.

## Orb Energy

**HQ**: Kenya

**Founded year:** 2006

**Funding raised in Oct 2026:** [**$2 million investment from KawiSafi Ventures**](https://african-startups.com/news/funding/kawisafi-ventures-invests-2-million-in-orb-energy-to-expand-solar-in-east-africa/)

Orb Energy is a vertically integrated solar provider offering rooftop and ground-mounted solar systems, solar-plus-battery storage, and in-house financing for commercial and industrial customers. The company manufactures its own solar panels at a factory in Bengaluru, India, and runs its African operations from a Nairobi base, with a growing C&I project pipeline across Kenya and other East African markets.

## Family Bank

**HQ**: Kenya

**Founded year:** 1984

**CEO:** Nancy Njau

**Funding raised in Oct 2026:** [**$10 million trade finance line of credit from the African Development Bank**](https://african-startups.com/countries/kenya/kenyas-family-bank-secures-10-million-credit-line-from-african-development-bank-to-expand-sme-and-agribusiness-lending/)

Family Bank is a Kenyan commercial lender and is regulated by the Central Bank of Kenya, serving over 1.2 million customers through 95 branches across 32 counties. The institution began in 1984 as the Family Bank Building Society before converting to a fully fledged commercial bank in 2007, with a strong focus on SME banking where MSMEs now make up more than 80% of its customer base. The new $10 million credit facility from AfDB will ease foreign currency shortages for Kenyan importers and exporters while widening lending to small businesses. Earmarked sectors include agriculture, manufacturing, health, renewable energy, and women-owned MSMEs. The deal aligns with the AfCFTA agenda and anchors the bank’s 2025 to 2029 corporate strategy.

## East Africa Foods

**HQ**: Tanzania

**CEO:** Elia Timotheo

**Funding raised in Oct 2026:** [**$40 million blended round**](https://african-startups.com/countries/united-republic-of-tanzania/tanzanian-agtech-east-africa-foods-secures-40-million-to-scale-food-supply-chain-infrastructure-across-east-africa/)

East Africa Foods is a Dar es Salaam-headquartered agritech and food distribution company that has spent the past three years building out physical and digital supply chain infrastructure across Tanzania. The platform sources produce from more than 28,000 registered smallholder farmers then aggregates, grades, stores, and processes it and distributes to over 10,000 urban retailers, including through its own Onja and Golden Banana brands.

## Ocular AI

**HQ**: San Francisco (Zimbabwe origin)

**Founder(s):** Michael Moyo and Louis Murerwa

**Funding raised in Oct 2026:** [**$2 million pre-Seed round led by Drive Capital**](https://african-startups.com/news/funding/ocular-ai-raises-2-million-pre-seed-to-build-voice-ai-training-data/)

Ocular AI is a San Francisco-based startup founded by two Zimbabwean entrepreneurs that supplies training and evaluation data for frontier voice and multimodal AI systems. The company builds datasets from real conversations, develops benchmarks such as its Converse-STT suite for speech-to-text models, and taps a vetted network of thousands of domain experts across medicine, law, finance, and software engineering. Its data pipeline records provenance, consent, and licensing for every clip and label, and the company reports seven-figure revenue serving frontier AI labs and Fortune 100 enterprises.

## Cloud9

**HQ**: Kenya

**Founded year:** 2025

**Founder(s):** Tesh Mbaabu and Mesongo Sibuti

**Funding raised in Oct 2026:** [**$500k from Alliance as part of an ongoing pre-Seed round**](https://african-startups.com/countries/kenya/kenyas-cloud9-secures-investment-from-alliance-to-build-borderless-banking-for-african-entrepreneurs/)

Cloud9 is a digital bank that bundles banking, global payments, and business tools into a single app aimed at informal businesses and retailers trading across Africa, with stablecoin-powered cross-border rails at its core. Cloud9 already reports more than 25,000 accounts and transaction volume climbing over 15% week over week, and it has acquired both Chpter and ticketing startup MTickets in all-stock deals.

## Vantage Payment Systems

**HQ**: Morocco

**Founded year:** 2014

**Chairman:** Ali Bettahi

**Funding raised in Oct 2026:** [**Undisclosed investment from AfricInvest’s Financial Inclusion Vehicle (FIVE)**](https://african-startups.com/news/funding/moroccan-fintech-vantage-payment-systems-secures-africinvest-backing-to-build-an-omnichannel-payments-platform/)

Vantage Payment Systems (VPS) is a Casablanca-based licensed payment institution founded in 2014 by Ali Bettahi, operating under the Payzone and Payexpress brands to serve Moroccan merchants. VPS processed more than 18 million transactions in 2025 across 600-plus active merchants and holds strategic integrations with American Express alongside a Mastercard partnership for tokenization and digital wallets. AfricInvest, through its evergreen Financial Inclusion Vehicle, has invested in Equity Invest, Bettahi’s personal holding company, lifting Equity Invest’s stake in VPS to 100% and consolidating the shareholder base.

## Vatar

**HQ**: Nigeria

**Founded year:** 2026

**Founder(s):** Shalom Rayhamen, Owen Rayhamen, and Anderson Oriahi

**Funding raised in Oct 2026:** [**$500k angel round at a $10 million valuation**](https://african-startups.com/countries/nigeria/nigerias-vatar-creator-of-viral-browser-game-lagos-life-raises-500k-to-scale-its-social-worlds-platform/)

Vatar is the Nigerian studio behind Lagos Life, a free browser-based life-simulation game set in a shared virtual version of Lagos where players create characters, take jobs, earn virtual naira, pay rent, vote for officials, and interact in real time. CEO Shalom Rayhamen built the first version in roughly a night using AI tools, and the title launched on October 1, 2026. The game has already drawn 4.3 million users across 15 countries, peaking at over 200,000 concurrent players, and monetises through advertising, brand deals, music promotion, football streaming, and in-game currency top-ups, generating more than $170,000 since launch.

## Healthleap

**HQ**: South Africa

**Founded year:** 2022

**Founder(s):** Josiah Meyer and Jemima Meyer

**Funding raised in Oct 2026:** [**$38 million across combined Seed and Series A rounds**](https://african-startups.com/countries/south-africa/south-africa-founded-healthleap-raises-38-million-to-help-hospitals-detect-missed-diagnoses-with-ai/)

Healthleap builds a clinical AI platform that scans every adult inpatient’s full medical record daily, including clinical notes, labs, vital signs, orders, and problem lists to flag conditions that doctors may have missed. Risk scores plug directly into hospitals’ electronic health record workflows. The company began with malnutrition detection and is expanding into congestive heart failure, pressure ulcers, and hospital-acquired infections. More than 50 hospitals use it, including Penn Medicine, Houston Methodist, Cedars-Sinai, and Emory Healthcare, with one deployment surfacing 39% more malnutrition cases and generating $11 million in incremental revenue.

## Kuunda

**Founded year:** 2018

**CEO:** Andrew Milne

**Funding raised in Oct 2026:** [**$5 million oversubscribed secondary share sale**](https://african-startups.com/news/funding/africa-lending-as-a-service-kuunda-completes-oversubscribed-secondary-sale-led-by-e4eafrica/)

Kuunda is a B2B2C digital lending-as-a-service provider that supplies banks, mobile money operators, and other financial institutions with the infrastructure to deliver credit through their existing customer networks. Its platform uses transaction and behavioural data to assess creditworthiness and handles the full loan lifecycle, with Hapa Cash covering short-term liquidity for mobile money agents and Kazi Cash offering longer-term growth financing for agents and micro-merchants. The company has grown bank partners from 6 to 16 and end users from 2.6 million to nearly 4 million, with over 870 million loans worth more than $4.4 billion cumulatively disbursed.

## DCC Holdings

**HQ:** South Africa

**CEO:** Carlos Ferreira

**Funding raised in Oct 2026:** [**$17 million in mezzanine debt**](https://african-startups.com/countries/south-africa/south-africas-dcc-holdings-secures-17-million-in-mezzanine-debt-from-kholo-capital/)

DCC Holdings is a South African distributor of information and communications technology products and solutions that has been operating for nearly four decades. The company maintains long-standing relationships with global technology manufacturers, runs an extensive reseller network, and operates its own logistics and distribution capabilities serving customers across the Southern African ICT market. Alongside senior management, private equity investor Kleoss Capital holds a stake in the business. DCC also runs initiatives tied to youth employment, support for learners with disabilities, SME reseller development, solar energy adoption, and water-saving measures.

## MAX

**HQ**: Nigeria

**Founded year:** 2015

**Founder(s):** Adetayo Bamiduro and Chinedu Azodoh

**Funding raised in Oct 2026:** [**Series B3 extension from US climate fintech Nithio**](https://african-startups.com/countries/nigeria/nigerias-max-extends-series-b3-to-29-million-with-nithio-backing-to-expand-electric-mobility/)

MAX is an integrated electric vehicle and battery subscription platform for commercial transport operators across Africa. Drivers pay a flat daily fee with no upfront cost, which covers the vehicle, insurance, maintenance, and training. The company operates across 20 cities in Nigeria, Ghana, and Cameroon, serving more than 60,000 drivers who have collectively completed over one billion trips. MAX says it has reached profitability in its home market of Nigeria after deploying over $56 million in fleet financing and repaying $44 million, and is targeting 250,000 drivers and more than $150 million in annual recurring revenue by 2027.

## Bisedge

**HQ**: Mauritius

**Founded year:** 2020

**Funding raised in Oct 2026:** [**$11.2 million senior debt financing from Finnfund**](https://african-startups.com/countries/nigeria/bisedge-secures-11-2-million-loan-from-finnfund-to-expand-electric-forklift-fleet-in-nigeria-and-east-africa/)

Bisedge supplies electric material-handling equipment and logistics services to manufacturing, warehousing, and distribution businesses through a Zero Capital Expenditure subscription model, where customers pay recurring fees instead of buying machines, with Bisedge managing maintenance and fleet operations. The company is the exclusive African partner of Linde Material Handling across nine markets, employs more than 1,350 people, and runs a fleet that is roughly 95% electric.

## Solarise Africa

**HQ**: Kenya

**Founded year:** 2018

**Founder(s):** Jan Albert Valk and Sakkie van Wijk

**Funding raised in Oct 2026:** [**$1.15 million EEP Africa grant,**](https://african-startups.com/news/funding/solarise-africa-secures-1-15-million-eep-africa-grant-to-enter-uganda-and-zambia/)

Solarise Africa is a decentralised renewable energy provider offering Energy-as-a-Service solutions to commercial, industrial, and social institution customers across Southern and East Africa. Its model covers engineering, equipment supply, operations, and maintenance, letting clients adopt solar PV, battery storage, and heat pumps without major upfront investment. The new 24-month programme targets 3 MW of new capacity, 4.5 GWh of renewable electricity, and 3,600 tonnes of avoided CO2.

## Swami Agri

**HQ**: Senegal

**Founded year:** 2021

**CEO:** Hitesh Gorasia

**Funding raised in Oct 2026:** [**$7 million investment from Cygnum Capital’s ALCB Fund**](https://african-startups.com/countries/senegal/cygnum-capitals-alcb-fund-invests-7-million-in-senegals-swami-agris-52-2-million-debut-green-bond/)

Swami Agri is a Senegalese agricultural company owned by the Senegindia group, focusing on growing potatoes and onions. They have issued a five-year green bond in West African CFA francs with a 7% interest rate, guaranteed by FAGACE. The funds will be used to build 16.7 MW of solar power and five solar-powered cold-storage facilities, which will hold 62,500 metric tons of produce. The company aims for 70-90% of its energy to come from renewable sources, reduce CO2 emissions by 20-30%, cut post-harvest losses by over 50%, and create at least 700 jobs.

## ChipChip

**HQ**: Ethiopia

**Founded year:** 2023

**Co-founder:** Bruk Getahun

**Funding raised in Oct 2026:** [**Undisclosed investment from Digital Africa**](https://african-startups.com/countries/ethiopia/digital-africa-makes-first-ethiopian-investment-backing-agtech-startup-chipchip/)

ChipChip is an Ethiopian agritech startup connecting local farmers with B2B buyers through a data- and AI-powered group-buying platform. Users form or join buying groups via its iOS and Android apps, and once a group reaches the required size, the order is placed at a discounted price and delivered directly to buyers’ doors. Produce is sourced from local farmers and suppliers, while group leaders can aggregate orders and earn rewards. The company’s mission is to raise farmer incomes while lowering household food costs across Ethiopia.

## Tactful AI

**HQ**: Egypt

**Founded year:** 2016

**Co-founders:** Mohamed Elmasry and Mohamed Hassan

**Funding raised in Oct 2026:** [**Undisclosed pre-Series A extension investment**](https://african-startups.com/news/funding/cairos-tactful-ai-secures-backing-from-former-e-ceo-hatem-dowidar-plans-to-raise-series-a-in-2027/)

Tactful AI is a Cairo-based company building an agentic AI customer experience platform that helps enterprises manage customer interactions, automate workflows, and analyse conversations across channels. Its next-generation agentic technology enables businesses to build and modify CX workflows in hours rather than months, with human oversight retained. The company operates teams in Cairo and Cambridge, UK, and serves clients including Elaraby Group, Raneen, 2B, Lucky One, Erada Finance, and Simplex. Since January 2025, its annual recurring revenue has grown 11.7x while monthly processed customer conversations rose 32x.

## Aqar Exit

**HQ**: Egypt

**Founded year:** 2026

**Founder:** Dr. Mahmoud Ammar

**Funding raised in Oct 2026:** [**$200k investment from Ayman Mamdouh Abbas**](https://african-startups.com/news/funding/egyptian-proptech-aqar-exit-raises-200k-at-2-million-valuation-targets-5-million-round-in-2027/)

Aqar Exit is an Egyptian proptech platform founded in July 2026 that matches sellers of instalment-based property contracts with buyers ready to take over those contracts at the original prices. Rather than facilitating primary property sales, it enables the transfer of existing instalment agreements, allowing sellers to recover what they have already paid without assignment fees, while buyers acquire units without resale premiums. Within roughly two months of launching, the company reports LE 9 billion in transactions on its platform.

## Afreenergy Solar

**HQ:** Senegal

**CEO:** Christian Cachat

**Funding raised in Oct 2026:** [**$13.4 million senior debt facility from REPP 2**](https://african-startups.com/countries/senegal/afreenergy-solar-secures-13-4-million-debt-facility-from-repp-2-to-expand-solar-and-storage-in-senegal/)

Afreenergy Solar develops and operates rooftop solar and battery storage systems for commercial and industrial customers in Senegal, owning and managing the assets under long-term energy agreements so clients can access on-site power without upfront capital. Its current rooftop portfolio stands at 2.7 MWp, with the planned expansion raising capacity to 14.9 MWp alongside 5.7 MWh of battery storage. The company serves retail, food manufacturing, agro-industrial, and infrastructure clients, helping them cut electricity costs by roughly 30%.

## Turuq Innovations

**HQ**: Egypt

**Founder(s):** Ahmed Atta and Karim Kamal

**Funding raised in Oct 2026:** [**Undisclosed Seed investment from Den VC**](https://african-startups.com/news/funding/egyptian-logistics-startup-turuq-innovations-raises-seed-funding-from-den-vc/)

Turuq Innovations is an Egyptian logistics startup running an integrated platform that unites warehousing, inventory management, order fulfilment, and last-mile delivery, giving online merchants end-to-end control over their logistics operations. The company serves growing e-commerce brands through a micro-fulfilment network built on proprietary technology, positioning itself as critical infrastructure for digital commerce in Egypt. Turuq is an alumnus of the InvestIT programme, launched in partnership with ITIDA, the Technology Innovation and Entrepreneurship Center, and Flat6Labs.

## Medikea

**HQ**: Tanzania

**Founded year:** 2020

**Founder(s):** Dr. Elvis Silayo and Desirè Ruhinda

**Funding raised in Oct 2026:** [**$1.2 million pre-Seed round**](https://african-startups.com/countries/united-republic-of-tanzania/dar-es-salaam-based-medikea-raises-1-2-million-to-expand-its-vertically-integrated-healthcare-model-across-tanzania/)

Medikea is a Tanzanian healthtech company operating a vertically integrated healthcare model that combines a telehealth app connecting patients to doctors with its own clinic network, pharmacies, and diagnostic labs. Based in Dar es Salaam and expanding across Tanzania, it will run four clinics once new sites in Arusha and Morogoro open, with plans to reach ten clinics by the end of 2027. Its first clinic broke even within twelve months and serves about 1,000 patients monthly, reportedly delivering care 25 times faster than public hospitals and 50 to 70 percent cheaper than traditional private providers. Medikea is targeting more than 100,000 patients over the next year.

## Vitara Agritech

**HQ**: Ghana

**Co-founder:** Mawuse Gyisun

**Funding raised in Oct 2026:** [**$2 million equity round led by a consortium**](https://african-startups.com/countries/ghana/ghanas-vitara-agritech-secures-2-million-to-scale-traceable-shea-supply-chains/)

Vitara Agritech, previously known as Sommalife, is a Ghanaian agri-tech company that creates traceable supply chains for shea by using its TreeSyt platform. This platform helps profile farmers, buy their produce, provide training, and monitor trees directly from the farm to buyers, eliminating middlemen. They work mainly with smallholder farmers in northern Ghana and have integrated mobile payments through MTN Ghana. So far, they have registered 150,000 farmers on TreeSyt, with 40,000 actively involved, including around 47,000 women farmers. Their fair pricing has increased farmers’ incomes by 20%, and they aim to reach one million farmers by 2030.

## CrissCross

**HQ**: South Africa

**Founded year:** 2022

**Founder(s):** Lex Campbell and Byron Coetsee

**Funding raised in Oct 2026:** [**Undisclosed strategic investment from Circle Ventures,**](https://african-startups.com/countries/south-africa/cape-towns-crisscross-receives-investment-from-circle-ventures-to-grow-stablecoin-payments-in-africa/)

CrissCross is a Cape Town-based cross-border payments business owned by Stitch Group that sells enterprise payment infrastructure through a single API. Its stack covers local collections, automated payouts, and corporate treasury management with real-time foreign exchange, linking blockchain settlement to local payment rails so money lands in bank accounts and mobile wallets. The platform supports more than 20 currencies and claims 99.99% uptime, operating across over 30 African markets. General manager James Cope leads the operation, which recently partnered with London-based stablecoin treasury platform Velocity.

## CYTO

**HQ**: Angola

**Founder(s):** Joachim Valot, Tamara Lerner, and Thiébault Husson

**Funding raised in Oct 2026:** [$ **40,000 secured through Catalytic Africa’s co-investment matching model**](https://african-startups.com/countries/angola/angolan-fintech-cyto-secures-40k-through-catalytic-africas-co-investment-model/)

CYTO is a fintech based in Luanda, Angola, creating a digital platform for money transfers and financial management. It targets the African diaspora in Europe, expatriates in Africa, and local freelancers and e-commerce businesses. The service includes an app and web portal that offer multi-currency accounts, payment APIs, and tools for invoicing, tax, and payroll. CYTO aims to compete with Stripe and Flutterwave in under-served markets and is focused on the 250 million people in Southern Africa. Funds from Catalytic Africa will be used for key hires, forming strategic partnerships, and acquiring new clients.

## NoorNation

**HQ**: Egypt

**Founded year:** 2021

**Founder(s):** Ragy Ramadan and Mohamed Khaled

**Funding raised in Oct 2026:** [**$1.05 million Seed round led by Prince Khaled bin Alwaleed’s KBW Ventures**](https://african-startups.com/news/funding/noornation-raises-1-05-million-seed-round-to-grow-pay-per-use-solar-irrigation-in-egypt/)

NoorNation is an Egyptian greentech startup building decentralised clean energy and water systems for farms, rural communities, and other off-grid users across Egypt and Sub-Saharan Africa. Its flagship LifeBox is a self-contained solar unit that powers electricity generation, irrigation, and water desalination, and the company also runs a Solar Irrigation-as-a-Service model letting farmers switch off diesel pumps without heavy upfront costs. Deployments with Linah Farms have already saved customers over $58,000 in diesel costs and $43,000 in grid electricity, with roughly 1.71 MWp of capacity delivered or in progress for that client alone.

## Okra Solar

HQ: Nigeria

**CEO:** Afnan Hannan

**Funding raised in Oct 2026:** [**$7 million flexible debt facility from British International Investment (BII)**](https://african-startups.com/news/funding/okra-solar-secures-7-million-bii-debt-facility-to-expand-mesh-grid-connections-across-rural-nigeria/)

Okra Solar builds mesh-grid technology that stitches together solar generation, battery storage, and smart controls so neighbouring homes and small businesses in off-grid communities can share electricity. Operating primarily in rural Nigeria, the company has already connected more than 13,000 households and installed over 2.3 MW of capacity, and expects the new facility to help it grow connections more than tenfold. The BII debt will fund upfront bulk purchases of batteries, solar PV equipment, and other long-lead components for roughly 150,000 new connections, enough to power an estimated 750,000 people, while cutting unit costs and shortening equipment delivery times to under a third of previous timelines.

## **Irrisol Engineering**

HQ: Uganda

**Founded year:** 2017

**Founder:** Joash Bwambale

**Funding raised in Oct 2026:** [**Undisclosed investment from Nordic Impact Funds,**](https://african-startups.com/countries/uganda/after-dob-equity-investment-ugandas-irrisol-engineering-attracts-nordic-impact-funds-backing/)

Irrisol Engineering is a Ugandan company that designs and runs solar-powered water systems for rural communities underserved by national utilities. Its mini-grids deliver piped water to households and community taps on a pay-as-you-use basis via mobile money, while standalone solar water systems serve schools, health facilities, businesses, and homes, with groundwater designs engineered to keep operating through droughts and floods. The company has built 14 community mini-grids and more than 600 standalone systems, reaching roughly 350,000 people, and is targeting one million by 2028.

## **GRIPS Energy Group**

**HQ: Côte d’Ivoire**

**CIO:** Carsten Jung

**Funding raised in Oct 2026:** [**Undisclosed growth equity round from Fortis Green Renewables Investment Management and Zeitinger Invest**](https://african-startups.com/news/funding/grips-energy-secures-growth-equity-to-expand-solar-and-battery-storage-across-sub-saharan-africa/)

GRIPS Energy Group develops, finances, builds, owns, and operates solar and battery storage projects for commercial and industrial customers across Sub-Saharan Africa, helping businesses cut power costs, improve electricity reliability, and meet sustainability targets. Owned by Anjano Energy Invest GmbH, the group is targeting more than 100 MW of solar and battery storage assets by 2030, which it estimates could avoid roughly 100,000 tonnes of CO₂ emissions annually.

## **ABA Life**

**HQ**: Morocco

**Launched:** 2021

**Founder(s):** Mohamed Benouda

**Funding raised in Oct 2026:** [**$40 million investment agreement with Admaius Capital Partners,**](https://african-startups.com/news/funding/moroccan-healthtech-aba-life-signs-40-million-investment-deal-with-admaius-capital-partners/)

ABA Life is the healthcare arm of Moroccan group ABA Technology, launched in 2021 to combine artificial intelligence, medical technology, telemedicine, connected health infrastructure, and clinical operations into a single integrated healthtech model. The company has delivered large-scale healthcare programmes with public institutions and foundations to widen access to care across Morocco, and says it has built a profitable platform ready to deploy at scale.

## **Miale Solar Inventions**

**HQ:** Kenya

**CFO:** Eric Mwenda

**Funding raised in Oct 2026:** [$5.5 million credit financing from Hivos-Triodos Fonds](https://african-startups.com/countries/kenya/kenyas-miale-solar-lands-5-5-million-from-hivos-triodos-fonds-to-deploy-9-mw-of-solar-capacity/)

Miale Solar is a Swedish-Kenyan renewable energy company headquartered in Nairobi that sells commercial solar PV systems through Energy-as-a-Service, Power Purchase Agreement, and lease-to-own models, letting clients adopt solar without upfront capital. Under these arrangements the company finances, builds, and maintains the systems while customers make regular payments under long-term contracts, with battery storage add-ons available to improve reliability. Healthcare facilities are a key target sector, and Miale is positioning for growth across the wider East African region.

Visited 433 times, 6 visit(s) today

Join the Club

### Subscribe to our   newsletter

Stay updated with the latest

news and articles.

- [ ] I agree to the [Terms and Conditions](https://african-startups.com/wp-content/uploads/2026/04/Terms_and_Conditions_African_startups.docx.pdf) and [Privacy Policy](https://african-startups.com/wp-content/uploads/2026/04/African_Startups_Privacy_Notice.docx.pdf)

Join to the Newsletter

### Follow our socials

- ![](https://african-startups.com/wp-content/uploads/2026/11/WorldRemit-founder-Ismail-Ahmed-launches-Odola-to-serve-African-diaspora-in-the-United-States-1024x576.jpg)



[Africa](https://african-startups.com/category/countries/africa/), [News](https://african-startups.com/category/news/)



### [WorldRemit founder Ismail Ahmed launches Odola to serve African diaspora in the United States](https://african-startups.com/news/worldremit-founder-ismail-ahmed-launches-odola-to-serve-african-diaspora-in-the-united-states/)

- ![](https://african-startups.com/wp-content/uploads/2026/11/Afreximbank-calls-for-more-investment-in-factoring-to-close-Africas-300-billion-SME-financing-gap-1024x683.jpg)



[News](https://african-startups.com/category/news/)



### [Afreximbank calls for more investment in factoring to close Africa’s $300 billion SME financing gap](https://african-startups.com/news/afreximbank-calls-for-more-investment-in-factoring-to-close-africas-300-billion-sme-financing-gap/)

- ![Axmed](https://african-startups.com/wp-content/uploads/2026/11/Untitled-Design-2026-11-24T194803.821-1024x576.jpg)



[Funding](https://african-startups.com/category/news/funding/), [News](https://african-startups.com/category/news/)



### [Axmed secures $4.28 million to expand access to affordable contraception in Kenya, Nigeria and beyond](https://african-startups.com/news/funding/axmed-secures-4-28-million-to-expand-access-to-affordable-contraception-in-kenya-nigeria-and-beyond/)