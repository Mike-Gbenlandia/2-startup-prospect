[Skip to main content](https://african-startups.com/news/funding/meet-the-african-startups-that-raised-funding-in-july-2026/#brx-content) [Skip to footer](https://african-startups.com/news/funding/meet-the-african-startups-that-raised-funding-in-july-2026/#brx-footer)

[Africa](https://african-startups.com/category/countries/africa/), [Funding](https://african-startups.com/category/news/funding/), [News](https://african-startups.com/category/news/)

July 31, 2026

# Meet the African startups that raised funding in July 2026

In H1 2026, African startups raised $1.44 billion through 146 deals, slightly more than the $1.42 billion raised in the same period of 2025, but with fewer overall deals (252 last year).

![](https://secure.gravatar.com/avatar/4f0dba0e1af7914c81749b91a5bf568f0407ea2a7eebe8692693080b7b4644dd?s=36&d=mm&r=g)

## Vigneshwar

Copy link to article

![](https://african-startups.com/wp-content/uploads/2026/07/Meet-the-African-startups-that-raised-funding-in-July-2026-1024x576.jpg)

_Editor’s note: [**African-Startups**](http://african-startups.com/) is a sister publication of [**EU-Startups**](https://www.eu-startups.com/), bringing trusted coverage of startups, venture capital, and innovation across Africa_.

July 2026 was a busy month for African startups raising capital, with deals spanning from FinTech, HealthTech, to food processing and EdTech across more than a dozen markets.

The funding varied from six-figure grants to eight-figure investments, with a diverse range of investors including pan-African venture funds, impact investors, and much more.

In H1 2026, African startups [raised](https://african-startups.com/know-how/african-startups-raised-1-44-billion-in-h1-2026-with-ev-startup-spiro-securing-the-single-biggest-deal/) $1.44 billion through 146 deals, slightly more than the $1.42 billion raised in the same period of 2025, but with fewer overall deals (252 last year).

A significant portion of the funding went to just seven companies, with Spiro leading at $320 million.

Debt financing increased by 37% year-on-year, rising from $448 million in H1 2025 to $614 million in H1 2026, as startups opted for debt to grow without giving up equity.

Additionally, H1 2026 saw a record number of mergers and acquisitions, with 63 deals compared to 29 in the previous year.

The World Bank’s Africa Economic Update [says](https://www.worldbank.org/en/region/afr/publication/africa-economic-update) that the growth in sub-Saharan Africa is projected to hold at 4.1% in 2026, unchanged from 2025, with projections revised downward by 0.3 percentage points from October 2025 estimates.

Even though the total value of new greenfield projects dropped by nearly a third, the number of projects actually went up, says the report.

As a result, more investors are participating with smaller investments, despite the challenging global conditions.

More investors are making smaller, focused investments across the continent, similar to trends in the startup scene, where money is being directed to fewer, but stronger companies.

Having said that, here are the startups that closed funding rounds in July 2026.

## ORA Technologies

Funding in July 2026: [$2 million Series A extension](https://african-startups.com/news/funding/moroccan-super-app-ora-technologies-raises-2-million-taking-series-a-funding-to-10-million/)

HQ: Morocco

Founded in 2023 by Omar Alami,  the ORA app offers multiple features, including P2P transactions, an e-commerce platform, on-demand services, chat functionality, social networking, and a digital wallet. Since its launch, the startup has been building what it calls a Moroccan super app, combining its ORA Cash mobile wallet with its food-delivery service Kooul into a single ecosystem. Total funding since inception now sits at nearly $12 million. Azur Innovation Fund led the extension round alongside other Moroccan private investors.

## Fincart

Funding in July 2026: [$2.8 million Seed](https://african-startups.com/news/funding/egypts-fincart-raises-2-8-million-to-scale-its-ai-powered-e-commerce-platform/)

HQ: Egypt

Founded in 2023 by Mostafa Masry and Nihal Ali, both with backgrounds at Careem, Glovo, Vodafone, and Delivery Hero, Fincart helps online merchants manage shipping, customer engagement, and cash advances from one dashboard. It plugs into more than 40 courier companies across Africa and currently works with over 450 merchants, having handled nearly $20 million in gross merchandise value. The funding round was co-led by Launch Africa and Antler MENAP, with participation from Yango Ventures, Five35 Ventures, Bluestream Capital, Hi2 Global, and Kalahari Venture Labs. It follows a pre-Seed in January 2025 led by Plus VC with Orbit Ventures and Plug and Play.

## Built Financial Technologies

Funding in July 2026: [Part of $500k from Village Capital](https://african-startups.com/news/funding/after-rivia-and-vdl-fulfilment-village-capital-invests-500k-in-three-more-ghanaian-startups/)

HQ: Ghana

It is a 10-year-old FinTech company that helps small businesses handle accounting, payroll, invoicing, payments, and inventory from one place. Founded by Edward Neequaye, it has onboarded more than 18,000 SMEs across Ghana, Kenya, and Nigeria and processed over $1.5 billion in invoices. Total funding to date stands at $365k. Backed through Village Capital’s Africa Ecosystem Catalysts Facility, a $4 million pilot vehicle funded by FMO and the Netherlands Enterprise Agency.

## GrowForMe

Funding in July 2026: [Part of $500k from Village Capital](https://african-startups.com/news/funding/after-rivia-and-vdl-fulfilment-village-capital-invests-500k-in-three-more-ghanaian-startups/)

HQ: Ghana

GrowForMe is an AgTech platform that connects farmers, aggregators, and buyers through input financing, warehousing, and commodity trading. GrowForMe says it has worked with more than 19,000 farmers and facilitated over $3.9 million in trade since launch. Earlier backers include Google’s Black Founders Fund, develoPPP Ventures, and the UN Capital Development Fund. Backed through Village Capital’s Africa Ecosystem Catalysts Facility.

## SAYeTECH

Funding in July 2026: [Part of $500k from Village Capital](https://african-startups.com/news/funding/after-rivia-and-vdl-fulfilment-village-capital-invests-500k-in-three-more-ghanaian-startups/)

HQ: Ghana

Winner of the 2024 MEST Africa Challenge, SAYeTECH designs and builds agricultural machinery like threshers and grain-cleaning equipment which can process crops up to 40 times faster than doing it by hand. Co-founded by Theodore Ohene-Botchway, the company is preparing for wider market entry across the ECOWAS region.

## Zazu

Funding in July 2026: [Undisclosed Seed round](https://african-startups.com/news/funding/south-africas-zazu-secures-seed-funding-from-launch-africa-ventures-to-scale-sme-banking-platform/)

HQ: South Africa

Co-founded in 2024 by Germain Bahri and Rinse Jacobs, both former Solarisbank executives, Zazu offers business accounts, invoicing, spend management, and bookkeeping tools for small businesses, what it calls a “Finance OS” for African SMEs. The startup currently lives in South Africa and Morocco. The Seed round was backed by Launch Africa Ventures, adding Zazu to the firm’s Seed Fund II portfolio alongside other FinTech bets such as Agridex, CreditCircuit, Liquify, and VaulFi. Zazu had previously closed a $1 million pre-Seed led by Plug and Play Ventures with angel participation from Launch Africa’s Zachariah George and founders from Qonto and Solarisbank.

## Reme-D

Funding in July 2026: [$1.45 million pre-Series A](https://african-startups.com/news/funding/after-500k-gif-backing-egypts-reme-d-raises-1-45-million-to-expand-molecular-diagnostics-manufacturing/)

HQ: Egypt

Founded in 2023 by Salma Tammam, Reme-D manufactures molecular diagnostic tests for diseases like tuberculosis, HIV, hepatitis, and HPV. What sets the company apart is that its tests are built to stay stable in heat with no cold chain needed, making them practical for remote clinics and areas with limited infrastructure. The team has grown from five to 50 people, has shipped over 550,000 tests across Egypt, Kenya, and Sudan, and has commercialised 30 diagnostic products from its Cairo facility. The round was led by Anara Impact Capital, with participation from the Global Innovation Fund and Africa Health Ventures. It follows a $500k equity investment from the Global Innovation Fund in April.

## Mylerz

Funding in July 2026: [$2 million in debt and equity](https://african-startups.com/news/funding/mylerz-raises-2-million-to-scale-its-logistics-infrastructure-across-egypt/)

HQ: Egypt

Founded in 2019 by Samer Gharaibeh, Mylerz handles fulfilment and last-mile delivery for online retailers across Egypt, Morocco, Jordan, Tunisia, and Algeria. The company says it maintains delivery success rates between 91% and 99%, well above the industry average of 82%, and offers same-day and next-day delivery alongside cash-on-delivery and mobile wallet payments. Total disclosed funding now sits at more than $11.6 million. The round was led by Lorax Capital Partners, which has backed the company since 2022, with participation from Egyptian payments company Fawry and existing investors.

## Flowt

Funding in July 2026: [Undisclosed pre-Seed](https://african-startups.com/news/funding/kenyan-fintech-flowt-reaches-first-close-of-pre-seed-round-to-finance-africas-climate-smart-smes/)

HQ: Kenya

Founded by Elana Laichena and Handel Dan Owour, Flowt provides working capital to small businesses in green manufacturing, climate-smart agriculture, renewable energy, and clean cooking. These companies make real revenue but often lack the financial documents that banks require Its platform plugs into accounting software and analyses banking and mobile money data to help lenders assess borrowers. Flowt has already tested with more than 15 potential borrowers and identified $1–2 million in pre-qualified loan demand. The first close was backed by impact investor Impacc and Delta40 Venture Studio, with grant funding from Argidius Foundation.

## Orient Enterprises

Funding in July 2026: [$1 million blended investment](https://african-startups.com/countries/kenya/kenyan-macadamia-processor-orient-enterprises-secures-1-million-to-expand-exports-and-restore-farmland/)

HQ: Kenya

Founded in 2018 by Rajiv Pandya, Orient Enterprises buys macadamia nuts from over 5,000 smallholder farmers, processes them at its own FSSC 22000-certified facility, and exports raw, roasted, and flavoured kernels under its Orient Chef brand to Europe, North America, and Asia. The company also runs its own tree nursery supplying seedlings to local farmers. Revenue hit $1.2 million in 2025, with more than 120 employees, 80% of them women. The investment came from climate investor Barka Fund.

## Wamly

Funding in July 2026: [$3.05 million Series A](https://african-startups.com/countries/south-africa/south-africas-wamly-secures-3-05-million-series-a-to-scale-all-in-one-hiring-platform/)

HQ: South Africa

Wamly was founded in 2018 by industrial psychologist Francois de Wet and entrepreneur Marnus Broodryk to solve the issues of slow and expensive hiring processes in large companies. The platform offers one-way video interviews, applicant tracking, psychometric assessments, and background checks all in one place and is used in 147 countries. A recent funding round led by Hlayisani Capital’s Venture Fund II will help Wamly grow its team, enhance its product, and expand into new markets beyond South Africa.

## Codar Tech Africa

Funding in July 2026: $1.5 million Seed

HQ: Nigeria

Codar is an EdTech company that trains people in digital and AI skills across Africa. Rather than following a traditional university model, it focuses on hands-on, employer-relevant courses, particularly in areas like machine learning and applied AI, where demand from FinTech, logistics, and enterprise software companies is rising fast but qualified talent remains scarce. The fresh capital will fund new AI course development, expansion into additional African markets, and deeper ties with the companies and institutions that end up hiring its graduates. Investor names have not been publicly disclosed.

## Mathesis Analytics

Funding in July 2026: Undisclosed

HQ: Nigeria

Founded by Winston Osuchukwu, Mathesis Analytics aims to improve credit access in Africa. Many people build good financial histories using various platforms like microfinance apps and digital wallets, but lenders can’t see this information. Mathesis solves this with “Personal Equity,” a system that compiles a person’s financial behaviour into a single, portable credit identity. So far, it has helped provide over eight million loans to more than two million borrowers in Nigeria. The company received investment from First Ally Capital to expand its operations across Africa.

## Fuzu

Funding in July 2026: Undisclosed from Jobtech Alliance

HQ: Kenya

Fuzu has spent over ten years developing talent infrastructure in Africa. It has shifted from being a jobs marketplace to managing global teams for AI data operations and quality assurance through its Fuzu Atlas product. In the next six months, the Jobtech Alliance will collaborate with Fuzu to secure international clients, refine the Atlas offering, and transition to more valuable AI projects. The funding for this initiative comes from the Jobtech Alliance, led by Mercy Corps and BFA Global.

## Kyosk

Funding in July 2026: Undisclosed from Jobtech Alliance

HQ: Kenya

Kyosk is a B2B commerce platform that serves over 200,000 informal retailers across Kenya, Nigeria, Uganda, and Tanzania, handling inventory access, delivery, and repeat ordering for small shopkeepers. The company recently shifted from running 25 warehouses in Kenya to one per country, focusing on route-level economics and operational efficiency. The investment came from the Jobtech Alliance, which backed Kyosk as part of its microenterprise thesis around platforms that work inside the daily workflows of informal retailers.

## Bridgement

Funding in July 2026: [$20.3 million](https://african-startups.com/countries/south-africa/south-african-fintech-bridgement-secures-20-3m-to-expand-ai-powered-sme-lending/)

HQ: South Africa

Founded in 2016 by Daniel Goldberg, Bridgement lends working capital to small businesses by pulling live data from bank accounts and accounting software like Xero and Sage, analysing thousands of data points to reach a credit decision, often within 24 hours, without the heavy collateral requirements traditional banks demand. The company has provided over $121 million (R2 billion) in funding for South African small and medium-sized enterprises (SMEs), in a market where the funding gap exceeds $23 billion (R386 billion). The round was backed by Rand Merchant Bank and Standard Bank, two of South Africa’s largest financial institutions.

## Dimension Data Limited

Funding in July 2026: [$2.9 million](https://african-startups.com/news/funding/nigerias-dimension-data-raises-2-9-million-in-first-tranche-of-14-7-million-bond-programme-to-expand-fibre-infrastructure/)

HQ: Nigeria

Dimension Data is a technology and connectivity provider that is using the proceeds to expand its fibre network across Nigeria. The company serves financial institutions, FinTech companies, enterprise customers, and other technology-driven sectors at a time when cloud adoption, digital financial services, and data-intensive applications are driving growing demand for reliable connectivity. The Series 1 corporate bond attracted participation from high-net-worth investors, with the transaction supported by FSDH Capital as well as Pathway Advisors Limited as lead issuing house and book runner, alongside Deloitte, STL, Fidelity Bank, and FCMB.

## Sevi

Funding in July 2026: [Undisclosed from Oxano Capital](https://african-startups.com/news/funding/kenyan-fintech-startup-sevi-secures-oxano-capital-backing-to-expand-working-capital-access/)

HQ: Kenya

Founded in 2018 by Dutch entrepreneurs Walter aan de Wiel and Bartel Verkruijssen, Sevi runs an “Order Now, Pay Later” platform that sits between suppliers and retailers. Retailers can stock inventory without putting up collateral, and suppliers get paid straight away. The company holds a Central Bank of Kenya digital credit licence, making it one of the country’s first licensed digital credit providers, and says its automated credit scoring has produced consistently low default rates. The backing came from Netherlands-based Oxano Capital, founded by Hans Walhout, Bram Quaak, and Peter van Dillen, which focuses on sub-Saharan African businesses in manufacturing, agro-processing, and technology.

## HyperDev

Funding in July 2026: [Over $1 million pre-Seed](https://african-startups.com/news/funding/south-africas-hyperdev-founded-by-ex-openai-and-google-experts-secures-over-1-million-pre-seed-funding/)

HQ: South Africa and Europe

Piotr Sobolewski and Riaz Moola built HyperDev after noticing that existing coding tools helped users start projects but fell apart when it came to actually shipping production-ready software. The platform’s standout feature: Guided Mode, walks developers through debugging, refinement, and deployment rather than just spitting out code snippets. Less than three months after launch, the platform is approaching 100,000 users across 14 countries. The pre-Seed round was backed by a network of venture capital investors from Europe and the UK, including Loom Ventures.

## Cue

Funding in July 2026: [$5 million](https://african-startups.com/news/funding/cape-town-based-cue-raises-5-million-to-scale-ai-powered-customer-service-agents/)

HQ: South Africa

Founded in 2015 by Richard Nischk, Cue builds customer service agents that handle queries across WhatsApp, webchat, email, Messenger, SMS, and voice. The company says its agents already resolve more than 60% of conversations without a human stepping in, and when they can’t, the platform hands off to a live agent with the full conversation history attached. The round was co-led by Knife Capital and FAM Investments, with the capital going towards building out the next wave of autonomous agents, expanding internationally, and investing in voice and security capabilities.

## M-KOPA Kenya Mobility

Funding in July 2026: [$30 million senior debt facility](https://african-startups.com/countries/kenya/m-kopas-kenya-mobility-lands-30-million-debt-facility-as-fintech-reaches-10-million-customers/)

HQ: Kenya

M-KOPA Kenya Mobility is the electric motorbike financing arm of M-KOPA, the pan-African FinTech that recently crossed 10 million customers across Kenya, Uganda, Ghana, Nigeria, and South Africa. The subsidiary was set up in 2023 to sell and finance electric two-wheelers, including the locally assembled Roam Air, the Ampersand Turaco, and Spiro battery-swapping bikes, as well as fleet solutions for platforms like Bolt. The $30 million facility came from Dutch development bank FMO, structured in three tranches: $22.5 million in direct loans and a $7.5 million commitment under FMO’s Building Prospects label. It is expected to carry 100% Green and 100% Reduced Inequalities labels under FMO’s impact framework.

## Biovac

Funding in July 2026: [Up to $15 million loan from the African Development Bank](https://african-startups.com/news/funding/cape-town-based-biovac-lands-up-to-15-million-afdb-loan-to-boost-african-vaccine-production/)

HQ: South Africa

Founded in 2003 in partnership with the South African government, Biovac is building what is set to become Africa’s first end-to-end multi-vaccine manufacturing facility in Cape Town.

The company has already delivered more than 450 million vaccine doses across Southern Africa and employs over 300 staff, half of them women. Once the new facility is complete by 2028, Biovac expects to produce up to 500 million doses a year, starting with oral cholera vaccine before expanding into polio, pneumonia, and meningitis vaccines through technology-transfer partnerships with Sanofi, Biological E, EuBiologics, and Bharat Biotech.

## Lemonade Payments

Funding in July 2026: [Undisclosed](https://african-startups.com/countries/kenya/kenyan-fintech-startup-lemonade-payments-lands-plug-and-play-backing-to-scale-payment-infrastructure-across-africa/)

HQ: Kenya

Founded in 2023 by Mark Machiri Kihara and Andrew Kibe, Lemonade Payments lets people send, receive, and manage money without exposing their personal details during the transaction. For businesses, the company offers a white-label solution that collects customer payments without directly handling sensitive data. Baobab Network invested first in Lemonade with a $100k cheque in 2024, and Plug and Play Ventures, the venture arm of the Silicon Valley innovation platform, has now joined the cap table as the company pushes into new African markets.

## Noma Services

Funding in July 2026: [$650k loan](https://african-startups.com/news/funding/nigerian-agribusiness-noma-services-secures-650k-working-capital-and-capex-loan/)

HQ: Abuja, Nigeria

Noma Services collects and processes staple crops like rice, maize, sorghum, and beans from over 11,000 smallholder farmers, supplying them to major FMCG companies. Established in 2018 and incorporated in 2021, the company operates central hubs in Mabushi, Niger, and Kaduna, as well as regional hubs in Kano and Jigawa. It provides farmers with irrigation facilities and tractors. Recently, it changed its business model from input financing to direct aggregation, which has gained the attention of its backers.The loan was extended through Sahel Capital’s Social Enterprise Fund for Agriculture in Africa (SEFAA), a fund that provides structured debt to agribusiness SMEs across 13 countries in sub-Saharan Africa.

## Flutterwave

Funding in July 2026: [Undisclosed strategic investment from Circle Ventures](https://african-startups.com/news/funding/after-ripple-backing-flutterwave-secures-circle-ventures-investment-to-expand-usdc-payments-and-settlement-in-africa/)

HQ: Nigeria

Founded by Olugbenga “GB” Agboola, Flutterwave is one of Africa’s most prominent

FinTech unicorns, having processed more than one billion transactions worth over $50 billion through its platform. Circle Ventures is investing in Flutterwave to help it add USDC stablecoin payments to its system. This will allow merchants to accept payments in local currencies while settling in USDC, which will reduce delays and costs.

Rather than replacing traditional payment rails, the company is building a multi-rail system spanning fiat, cards, bank transfers, and stablecoins so businesses can pick what works best for them.

## Nesa Power Group

Funding in July 2026: [$9.14 million mezzanine debt](https://african-startups.com/countries/south-africa/south-africas-nesa-power-secures-9-14-million-mezzanine-debt-funding-to-scale-solar-ppa-portfolio/)

HQ: South Africa

Founded in 2015, Nesa Power builds and operates commercial and industrial solar installations across South Africa. The company and its founders have put up more than 46 megawatt-peak of solar generation capacity and 6.5 megawatt-hours of battery storage to date, and have raised over $24 million (R400 million) in managed funds that invest in and run more than 70 solar assets under long-term power purchase agreements. The fresh capital will go towards acquiring new solar sites and growing the PPA portfolio as the company scales its solar, storage, and energy services. The funding came from Maia Capital Partners out of its Maia Debt Impact Fund I, which backs mid-market companies in renewable energy, affordable housing, healthcare, and education.

## BrainsMingle

Funding in July 2026: [$400k Seed](https://african-startups.com/news/funding/brainsmingle-secures-400k-seed-investment-to-scale-its-video-first-professional-networking-platform/)

HQ: Egypt

Founded by Belal Amin and Yousef Gamal, BrainsMingle is a video-first professional networking platform built around live human interaction rather than static feeds and profiles. Experts can run live sessions, manage bookings and payments, and build communities, while professionals use it to find mentors and join peer conversations. The platform has attracted users from more than 90 countries, and universities, accelerators, and enterprises use it as a branded hub for mentorship and learning, replacing traditional learning management systems. The Seed round came from BasharSoft Group, Egypt’s largest human capital technology company, which runs WUZZUF and Forasna and serves over nine million users.

Visited 336 times, 4 visit(s) today

Join the Club

### Subscribe to our   newsletter

Stay updated with the latest

news and articles.

- [ ] I agree to the [Terms and Conditions](https://african-startups.com/wp-content/uploads/2026/04/Terms_and_Conditions_African_startups.docx.pdf) and [Privacy Policy](https://african-startups.com/wp-content/uploads/2026/04/African_Startups_Privacy_Notice.docx.pdf)

Join to the Newsletter

### Follow our socials

- ![](https://african-startups.com/wp-content/uploads/2026/11/Baobab-Group-issues-51-million-sustainability-linked-bonds-in-Cote-dIvoire-and-Senegal-1024x576.jpg)



[Côte d'Ivoire](https://african-startups.com/category/countries/cote-divoire/), [News](https://african-startups.com/category/news/), [Senegal](https://african-startups.com/category/countries/senegal/)



### [Baobab Group issues $51 million sustainability-linked bonds in Côte d’Ivoire and Senegal](https://african-startups.com/countries/cote-divoire/baobab-group-issues-51-million-sustainability-linked-bonds-in-cote-divoire-and-senegal/)

- ![Korridor](https://african-startups.com/wp-content/uploads/2026/11/freight-africa-Apis--1024x576.jpg)



[Acquisitions](https://african-startups.com/category/news/acquisitions/), [News](https://african-startups.com/category/news/)



### [London-based Apis Partners acquires majority stake in African logistics FinTech Korridor](https://african-startups.com/news/london-based-apis-partners-acquires-majority-stake-in-african-logistics-fintech-korridor/)

- ![](https://african-startups.com/wp-content/uploads/2026/11/Swedfund-commits-35-million-to-Zambias-Zanaco-to-expand-lending-to-small-businesses-and-women-entrepreneurs-1024x576.jpg)



[Funding](https://african-startups.com/category/news/funding/), [News](https://african-startups.com/category/news/)



### [Swedfund commits $35 million to Zambia’s Zanaco to expand lending to small businesses and women entrepreneurs](https://african-startups.com/news/funding/swedfund-commits-35-million-to-zambias-zanaco-to-expand-lending-to-small-businesses-and-women-entrepreneurs/)