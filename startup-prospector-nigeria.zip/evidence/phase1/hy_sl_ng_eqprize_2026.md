[Skip to content](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2026#main-content)

Live market

NGX ASI245,685.87-0.32%

JSE TOP40105,663.54-0.26%

NGX ASI245,685.87-0.32%

JSE TOP40105,663.54-0.26%

NGX ASI245,685.87-0.32%

JSE TOP40105,663.54-0.26%

NGX ASI245,685.87-0.32%

JSE TOP40105,663.54-0.26%

Updated **24 Nov 2026****7,030 rounds tracked**Source: **SLA Funding Index** [How we count →](https://www.startuplist.africa/methodology) [Submit a round →](https://www.startuplist.africa/submit-startup)

Year · 2026▾

- [All years](https://www.startuplist.africa/fundings/nigeria/equity-free-prize)
- [2026](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2026)
- [2025](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2025)
- [2024](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2024)
- [2023](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2023)
- [2022](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2022)
- [2021](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2021)
- [2020](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2020)
- [2019](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2019)
- [2018](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2018)
- [2017](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2017)
- [2016](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2016)
- [2015](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2015)

[×](https://www.startuplist.africa/fundings/nigeria/equity-free-prize)

Round · Equity-free prize▾

- [Seed](https://www.startuplist.africa/fundings/nigeria/seed/2026)
- [Pre-seed](https://www.startuplist.africa/fundings/nigeria/pre-seed/2026)
- [Grant](https://www.startuplist.africa/fundings/nigeria/grant/2026)
- [Venture](https://www.startuplist.africa/fundings/nigeria/venture/2026)
- [Debt Financing](https://www.startuplist.africa/fundings/nigeria/debt-financing/2026)
- [Series A](https://www.startuplist.africa/fundings/nigeria/series-a/2026)
- [Non-equity Assistance](https://www.startuplist.africa/fundings/nigeria/non-equity-assistance/2026)
- [Funding Round](https://www.startuplist.africa/fundings/nigeria/funding-round/2026)
- [Series B](https://www.startuplist.africa/fundings/nigeria/series-b/2026)
- [Angel](https://www.startuplist.africa/fundings/nigeria/angel/2026)
- [Private Equity](https://www.startuplist.africa/fundings/nigeria/private-equity/2026)
- [Convertible Note](https://www.startuplist.africa/fundings/nigeria/convertible-note/2026)
- [Series C](https://www.startuplist.africa/fundings/nigeria/series-c/2026)
- [Corporate](https://www.startuplist.africa/fundings/nigeria/corporate/2026)
- [Equity Crowdfunding](https://www.startuplist.africa/fundings/nigeria/equity-crowdfunding/2026)
- [Undisclosed](https://www.startuplist.africa/fundings/nigeria/undisclosed/2026)
- [Post-IPO Equity](https://www.startuplist.africa/fundings/nigeria/post-ipo-equity/2026)
- [Series D](https://www.startuplist.africa/fundings/nigeria/series-d/2026)
- [Pre-Series A](https://www.startuplist.africa/fundings/nigeria/pre-series-a/2026)
- [Investment (round not specified)](https://www.startuplist.africa/fundings/nigeria/investment-round-not-specified/2026)
- [EmFi Series](https://www.startuplist.africa/fundings/nigeria/emfi-series/2026)
- [Equity-free prize](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2026)
- [Post-IPO Debt](https://www.startuplist.africa/fundings/nigeria/post-ipo-debt/2026)
- [Equity investment](https://www.startuplist.africa/fundings/nigeria/equity-investment/2026)
- [Accelerator](https://www.startuplist.africa/fundings/nigeria/accelerator/2026)
- [Equity](https://www.startuplist.africa/fundings/nigeria/equity/2026)
- [Series E](https://www.startuplist.africa/fundings/nigeria/series-e/2026)
- [Secondary Market](https://www.startuplist.africa/fundings/nigeria/secondary-market/2026)
- [Undisclosed investment](https://www.startuplist.africa/fundings/nigeria/undisclosed-investment/2026)
- [Pre-Series B](https://www.startuplist.africa/fundings/nigeria/pre-series-b/2026)

[×](https://www.startuplist.africa/fundings/nigeria/2026)

Country · Nigeria▾

- [Nigeria](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2026)
- [Kenya](https://www.startuplist.africa/fundings/kenya/equity-free-prize/2026)
- [Egypt](https://www.startuplist.africa/fundings/egypt/equity-free-prize/2026)
- [South Africa](https://www.startuplist.africa/fundings/south-africa/equity-free-prize/2026)
- [Ghana](https://www.startuplist.africa/fundings/ghana/equity-free-prize/2026)
- [Morocco](https://www.startuplist.africa/fundings/morocco/equity-free-prize/2026)
- [Uganda](https://www.startuplist.africa/fundings/uganda/equity-free-prize/2026)
- [Rwanda](https://www.startuplist.africa/fundings/rwanda/equity-free-prize/2026)
- [Tunisia](https://www.startuplist.africa/fundings/tunisia/equity-free-prize/2026)
- [Côte d'Ivoire](https://www.startuplist.africa/fundings/cote-divoire/equity-free-prize/2026)
- [Senegal](https://www.startuplist.africa/fundings/senegal/equity-free-prize/2026)
- [Tanzania](https://www.startuplist.africa/fundings/tanzania/equity-free-prize/2026)
- [Mauritius](https://www.startuplist.africa/fundings/mauritius/equity-free-prize/2026)
- [Zambia](https://www.startuplist.africa/fundings/zambia/equity-free-prize/2026)
- [Ethiopia](https://www.startuplist.africa/fundings/ethiopia/equity-free-prize/2026)
- [DR Congo](https://www.startuplist.africa/fundings/dr-congo/equity-free-prize/2026)
- [Cameroon](https://www.startuplist.africa/fundings/cameroon/equity-free-prize/2026)
- [Algeria](https://www.startuplist.africa/fundings/algeria/equity-free-prize/2026)
- [Mali](https://www.startuplist.africa/fundings/mali/equity-free-prize/2026)
- [Zimbabwe](https://www.startuplist.africa/fundings/zimbabwe/equity-free-prize/2026)
- [Togo](https://www.startuplist.africa/fundings/togo/equity-free-prize/2026)
- [Angola](https://www.startuplist.africa/fundings/angola/equity-free-prize/2026)
- [Sierra Leone](https://www.startuplist.africa/fundings/sierra-leone/equity-free-prize/2026)
- [Malawi](https://www.startuplist.africa/fundings/malawi/equity-free-prize/2026)
- [Somalia](https://www.startuplist.africa/fundings/somalia/equity-free-prize/2026)
- [Mozambique](https://www.startuplist.africa/fundings/mozambique/equity-free-prize/2026)
- [Guinea](https://www.startuplist.africa/fundings/guinea/equity-free-prize/2026)
- [Burkina Faso](https://www.startuplist.africa/fundings/burkina-faso/equity-free-prize/2026)
- [Benin](https://www.startuplist.africa/fundings/benin/equity-free-prize/2026)
- [Lesotho](https://www.startuplist.africa/fundings/lesotho/equity-free-prize/2026)
- [Sudan](https://www.startuplist.africa/fundings/sudan/equity-free-prize/2026)
- [Namibia](https://www.startuplist.africa/fundings/namibia/equity-free-prize/2026)
- [Seychelles](https://www.startuplist.africa/fundings/seychelles/equity-free-prize/2026)
- [Botswana](https://www.startuplist.africa/fundings/botswana/equity-free-prize/2026)
- [Libya](https://www.startuplist.africa/fundings/libya/equity-free-prize/2026)
- [Madagascar](https://www.startuplist.africa/fundings/madagascar/equity-free-prize/2026)
- [Liberia](https://www.startuplist.africa/fundings/liberia/equity-free-prize/2026)
- [Congo](https://www.startuplist.africa/fundings/congo/equity-free-prize/2026)
- [Gabon](https://www.startuplist.africa/fundings/gabon/equity-free-prize/2026)
- [Côte D'ivoire](https://www.startuplist.africa/fundings/cote-divoire/equity-free-prize/2026)
- [Niger](https://www.startuplist.africa/fundings/niger/equity-free-prize/2026)
- [Mauritania](https://www.startuplist.africa/fundings/mauritania/equity-free-prize/2026)
- [Eswatini](https://www.startuplist.africa/fundings/eswatini/equity-free-prize/2026)
- [Djibouti](https://www.startuplist.africa/fundings/djibouti/equity-free-prize/2026)

[×](https://www.startuplist.africa/fundings/equity-free-prize/2026)

Sector▾

- [Financial Services](https://www.startuplist.africa/fundings/nigeria/financial-services/equity-free-prize/2026)
- [Health Care](https://www.startuplist.africa/fundings/nigeria/health-care/equity-free-prize/2026)
- [FinTech](https://www.startuplist.africa/fundings/nigeria/fintech/equity-free-prize/2026)
- [E-Commerce](https://www.startuplist.africa/fundings/nigeria/e-commerce/equity-free-prize/2026)
- [AgriTech](https://www.startuplist.africa/fundings/nigeria/agritech/equity-free-prize/2026)
- [Energy](https://www.startuplist.africa/fundings/nigeria/energy/equity-free-prize/2026)
- [Agriculture](https://www.startuplist.africa/fundings/nigeria/agriculture/equity-free-prize/2026)
- [EdTech](https://www.startuplist.africa/fundings/nigeria/edtech/equity-free-prize/2026)
- [Transportation](https://www.startuplist.africa/fundings/nigeria/transportation/equity-free-prize/2026)
- [Logistics](https://www.startuplist.africa/fundings/nigeria/logistics/equity-free-prize/2026)
- [Education](https://www.startuplist.africa/fundings/nigeria/education/equity-free-prize/2026)
- [Information Technology Services](https://www.startuplist.africa/fundings/nigeria/information-technology-services/equity-free-prize/2026)
- [Renewable Energy](https://www.startuplist.africa/fundings/nigeria/renewable-energy/equity-free-prize/2026)
- [Artificial Intelligence](https://www.startuplist.africa/fundings/nigeria/artificial-intelligence/equity-free-prize/2026)
- [SaaS](https://www.startuplist.africa/fundings/nigeria/saas/equity-free-prize/2026)
- [Banking](https://www.startuplist.africa/fundings/nigeria/banking/equity-free-prize/2026)
- [Manufacturing](https://www.startuplist.africa/fundings/nigeria/manufacturing/equity-free-prize/2026)
- [Marketplace](https://www.startuplist.africa/fundings/nigeria/marketplace/equity-free-prize/2026)
- [Finance](https://www.startuplist.africa/fundings/nigeria/finance/equity-free-prize/2026)
- [Insurance](https://www.startuplist.africa/fundings/nigeria/insurance/equity-free-prize/2026)
- [Automotive](https://www.startuplist.africa/fundings/nigeria/automotive/equity-free-prize/2026)
- [Advertising](https://www.startuplist.africa/fundings/nigeria/advertising/equity-free-prize/2026)
- [Human Resources](https://www.startuplist.africa/fundings/nigeria/human-resources/equity-free-prize/2026)
- [Software](https://www.startuplist.africa/fundings/nigeria/software/equity-free-prize/2026)
- [Biotechnology](https://www.startuplist.africa/fundings/nigeria/biotechnology/equity-free-prize/2026)
- [Information Technology](https://www.startuplist.africa/fundings/nigeria/information-technology/equity-free-prize/2026)
- [Health](https://www.startuplist.africa/fundings/nigeria/health/equity-free-prize/2026)
- [Big Data](https://www.startuplist.africa/fundings/nigeria/big-data/equity-free-prize/2026)
- [Electric Mobility](https://www.startuplist.africa/fundings/nigeria/electric-mobility/equity-free-prize/2026)
- [HealthTech](https://www.startuplist.africa/fundings/nigeria/healthtech/equity-free-prize/2026)
- [Gaming](https://www.startuplist.africa/fundings/nigeria/gaming/equity-free-prize/2026)
- [Payments](https://www.startuplist.africa/fundings/nigeria/payments/equity-free-prize/2026)
- [Food and Beverage](https://www.startuplist.africa/fundings/nigeria/food-and-beverage/equity-free-prize/2026)
- [PropTech](https://www.startuplist.africa/fundings/nigeria/proptech/equity-free-prize/2026)
- [Consumer Goods](https://www.startuplist.africa/fundings/nigeria/consumer-goods/equity-free-prize/2026)
- [E-Learning](https://www.startuplist.africa/fundings/nigeria/e-learning/equity-free-prize/2026)
- [InsurTech](https://www.startuplist.africa/fundings/nigeria/insurtech/equity-free-prize/2026)
- [Digital Health](https://www.startuplist.africa/fundings/nigeria/digital-health/equity-free-prize/2026)
- [Blockchain](https://www.startuplist.africa/fundings/nigeria/blockchain/equity-free-prize/2026)
- [Retail](https://www.startuplist.africa/fundings/nigeria/retail/equity-free-prize/2026)

Size▾

- [Undisclosed](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2026?bucket=undisclosed)
- [Under $1M](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2026?bucket=under-1m)
- [$1M – $5M](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2026?bucket=1m-5m)
- [$5M – $20M](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2026?bucket=5m-20m)
- [$20M – $50M](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2026?bucket=20m-50m)
- [$50M+](https://www.startuplist.africa/fundings/nigeria/equity-free-prize/2026?bucket=50m-plus)

8 rounds · 2026 · Equity-free prize · Nigeria

## Equity-free prize rounds in Nigeria, 20268 · newest first

[All 7,030 rounds →](https://www.startuplist.africa/fundings)

| # | Startup | Round | HQ | Investors | Amount | Date |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | AC<br>[Acecore](https://www.startuplist.africa/startups/acecore) Renewable EnergyEquity-free prize · Nigeria | [Equity-free prize](https://www.startuplist.africa/funding/acecore-equity-free-prize-10k-usd-af0d5df) | Nigeria | Not disclosed | $10K30 Oct | 30 Oct |
| 2 | SU<br>[Supplya](https://www.startuplist.africa/startups/supplya) BNPLEquity-free prize · Nigeria | [Equity-free prize](https://www.startuplist.africa/funding/supplya-equity-free-prize-5000-usd-d59d15a) | Nigeria | Not disclosed | $5K30 Oct | 30 Oct |
| 3 | NA<br>[Navidyn](https://www.startuplist.africa/startups/navidyn) RoboticsEquity-free prize · Nigeria | [Equity-free prize](https://www.startuplist.africa/funding/navidyn-equity-free-prize-2500-usd-8fca81c) | Nigeria | Not disclosed | $3K30 Oct | 30 Oct |
| 4 | ![](https://www.startuplist.africa/_next/image?url=https%3A%2F%2Fs3.amazonaws.com%2Fstartuplist.africa%2Fstartups%2Feight-medical%2Feight-medical-logo.png&w=64&q=75)<br>[Eight Medical](https://www.startuplist.africa/startups/eight-medical) Health Care · LagosEquity-free prize · Nigeria | [Equity-free prize](https://www.startuplist.africa/funding/eight-medical-equity-free-prize-19k-usd-16b7cf9) | Nigeria | [Cascador](https://www.startuplist.africa/investors/cascador), [Wema Bank](https://www.startuplist.africa/investors/wema-bank) | $19K24 Oct | 24 Oct |
| 5 | ![](https://www.startuplist.africa/_next/image?url=https%3A%2F%2Fs3.amazonaws.com%2Fstartuplist.africa%2Fstartups%2Fuwana-energy%2F8f7b2e8a-5d0c-4ff7-a049-6f77f201febb.png&w=64&q=75)<br>[Uwana Energy](https://www.startuplist.africa/startups/uwana-energy) CleanTech · IkoyiEquity-free prize · Nigeria | [Equity-free prize](https://www.startuplist.africa/funding/uwana-energy-equity-free-prize-5000-usd-fdf3554) | Nigeria | [Cascador](https://www.startuplist.africa/investors/cascador) | $15K24 Oct | 24 Oct |
| 6 | PK<br>[Protein Kapital](https://www.startuplist.africa/startups/protein-kapital) AgriTechEquity-free prize · Nigeria | [Equity-free prize](https://www.startuplist.africa/funding/protein-kapital-equity-free-prize-70k-usd-007311e) | Nigeria | [NSIA](https://www.startuplist.africa/investors/nsia) | $70K24 Oct | 24 Oct |
| 7 | TR<br>[Tryctor](https://www.startuplist.africa/startups/tryctor) AgriTech · IlorinEquity-free prize · Nigeria | [Equity-free prize](https://www.startuplist.africa/funding/tryctor-equity-free-prize-4000-usd-7b459b4) | Nigeria | Not disclosed | $4K24 Oct | 24 Oct |
| 8 | ![](https://www.startuplist.africa/_next/image?url=https%3A%2F%2Fs3.amazonaws.com%2Fstartuplist.africa%2Fstartups%2Fnearpays%2Fa2653ea6-7723-4b6d-867b-2b15fa017fbd.png&w=64&q=75)<br>[Nearpays](https://www.startuplist.africa/startups/nearpays) FinTech · AbujaEquity-free prize · Nigeria | [Equity-free prize](https://www.startuplist.africa/funding/nearpays-equity-free-prize-100k-usd-3e6400e) | Nigeria | Not disclosed | $100K16 Sep | 16 Sep |

SLA Funding Index · as of 25 Nov 2026

## Questions about Equity-free prize rounds in Nigeria, 2026

How many Equity-free prize rounds did startups in Nigeria raise in 2026?StartupList Africa tracks 8 rounds in this view as of 25 Nov 2026, listed newest first.

How often is funding data updated?Our funding database is updated daily. We track disclosed rounds from press releases, regulatory filings, investor announcements, and verified startup submissions.

What funding stages are tracked?We track all stages including Pre-Seed, Seed, Series A through Series E+, as well as alternative capital types like angel investments, grants, debt financing, and convertible notes.

How is the funding amount determined?Amounts shown are the disclosed USD equivalent at the time of announcement. Where the round was denominated in local currency, we convert using the exchange rate on the announcement date.