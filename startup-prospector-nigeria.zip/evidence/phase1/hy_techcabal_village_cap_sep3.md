Happily Authenticated! ×

- [Funding](https://techcabal.com/category/startups/funding/)



# Village Capital deploys $450,000 in first Nigeria investments





By



[Opeyemi Kareem](https://techcabal.com/author/opeyemi-kareem/)





3rd Sep, 2026





[![Google](https://www.gstatic.com/images/branding/product/1x/googleg_32dp.png)Get TC updates in your Newsfeed](https://www.google.com/preferences/source?q=techcabal.com)





[![Village Capital deploys $450,000 in first Nigeria investments](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/09/Village-Capital.png)](https://techcabal.com/2026/09/03/village-capital-nigeria-investments/) _Soji Sanyaolu, AirSmat's founder and CEO and Adeshina Adewumi, co-founder and CEO of Trade Lenda. Image Source: Village Capital._













Share







[Share on Facebook](https://www.facebook.com/dialog/share?app_id=252296078952383&display=popup&href=https%3A%2F%2Ftechcabal.com%2F2026%2F09%2F03%2Fvillage-capital-nigeria-investments%2F)[Share on Twitter](https://twitter.com/intent/tweet?url=https%3A%2F%2Ftechcabal.com%2F2026%2F09%2F03%2Fvillage-capital-nigeria-investments%2F&text=Village%20Capital%20deploys%20%24450%2C000%20in%20first%20Nigeria%20investments)[Share on LinkedIn](https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Ftechcabal.com%2F2026%2F09%2F03%2Fvillage-capital-nigeria-investments%2F&title=Village%20Capital%20deploys%20%24450%2C000%20in%20first%20Nigeria%20investments&summary=The%20Nigeria%20investments%20come%20as%20early-stage%20startups%20continue%20to%20face%20a%20difficult%20funding%20environment.)[Share on WhatsApp](https://api.whatsapp.com/send?text=https%3A%2F%2Ftechcabal.com%2F2026%2F09%2F03%2Fvillage-capital-nigeria-investments%2F)[Share on Email](mailto:?body=https%3A%2F%2Ftechcabal.com%2F2026%2F09%2F03%2Fvillage-capital-nigeria-investments%2F&subject=Village%20Capital%20deploys%20%24450%2C000%20in%20first%20Nigeria%20investments)













Share







[Share on Facebook](https://www.facebook.com/dialog/share?app_id=252296078952383&display=popup&href=https%3A%2F%2Ftechcabal.com%2F2026%2F09%2F03%2Fvillage-capital-nigeria-investments%2F)[Share on Twitter](https://twitter.com/intent/tweet?url=https%3A%2F%2Ftechcabal.com%2F2026%2F09%2F03%2Fvillage-capital-nigeria-investments%2F&text=Village%20Capital%20deploys%20%24450%2C000%20in%20first%20Nigeria%20investments)[Share on LinkedIn](https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Ftechcabal.com%2F2026%2F09%2F03%2Fvillage-capital-nigeria-investments%2F&title=Village%20Capital%20deploys%20%24450%2C000%20in%20first%20Nigeria%20investments&summary=The%20Nigeria%20investments%20come%20as%20early-stage%20startups%20continue%20to%20face%20a%20difficult%20funding%20environment.)[Share on WhatsApp](https://api.whatsapp.com/send?text=https%3A%2F%2Ftechcabal.com%2F2026%2F09%2F03%2Fvillage-capital-nigeria-investments%2F)[Share on Email](mailto:?body=https%3A%2F%2Ftechcabal.com%2F2026%2F09%2F03%2Fvillage-capital-nigeria-investments%2F&subject=Village%20Capital%20deploys%20%24450%2C000%20in%20first%20Nigeria%20investments)











Village Capital, a global nonprofit that backs high-impact startups, has deployed $450,000 from its Africa Ecosystem Catalysts Facility into two Nigerian startups, marking the investment vehicle’s entry into the country after [backing two Ghanaian companies](https://techcabal.com/2026/05/06/village-capital-backs-two-ghanaian-startups-with-350000-form-latest-fund/) earlier this year.



The backed companies include [Trade Lenda](https://tradelenda.com/), a digital financial services platform for small and medium-sized businesses, and [AirSmat](https://airsmat.com/), a climate-tech company that turns agricultural waste into biochar-based fertiliser. The latest investments bring the facility’s total portfolio to seven startups across Ghana and Nigeria.



Village Capital [launched the $4 million facility in July 2025](https://techcabal.com/2025/07/15/village-capital-to-support-startups-through-local-partners/) with backing from the Dutch Entrepreneurial Development Bank (FMO) and the Netherlands Enterprise Agency (RVO). It targets early-stage companies working on economic mobility and climate resilience, using local ecosystem organisations to identify startups that traditional investors may overlook.



The Nigeria investments come as early-stage startups continue to face a difficult funding environment. In the first half of 2026, African startups [raised just $9 million in early-stage funding](https://insights.techcabal.com/state-of-tech-in-africa-h1-2026-recap-is-consolidation-the-new-growth-story/), down from $25 million in the same period a year earlier. The facility’s model is designed to address that gap by working with local ecosystem partners that can identify founders and structure capital around their needs.



“What stands out about these startups is how they’re strengthening the systems that businesses and farmers rely on to grow,” said Husein Merchant, Investment Officer at Village Capital.



Trade Lenda, which provides digital business loans, embedded finance and Sharia-compliant financing, has supported more than 260,000 SMEs and farmers across five of Nigeria’s six geopolitical zones, according to the company. Women account for 66% of its customers.



“The capital has enabled us to accelerate our growth, acquire a higher license, and attract more competitive funding,” said Adeshina Adewumi, co-founder and CEO of Trade Lenda. He added that the investment helped the company secure an additional $2 million in local debt facilities at lower rates, allowing it to expand lending while reducing its cost of capital.



AirSmat is using its investment to complete and commission a commercial factory for its biochar-based fertiliser and expand production. Its technology converts agricultural waste into biochar, which can improve soil health while removing carbon and creating additional income opportunities for farmers through carbon markets.



















“Access to capital structured around the realities of building a climate-tech company has been transformative for AirSmat,” said Soji Sanyaolu, the company’s founder and CEO.



[Africa Fintech Foundry](https://africafintechfoundry.ng/), one of the facility’s local ecosystem partners, helped source the two Nigerian investments. The organisation works with Village Capital to identify startups with potential and provide local market insight during the investment process.



The partnership reflects a different approach to deploying early-stage capital in African markets. Rather than relying solely on a central investment team to source deals, Village Capital works with local Entrepreneur Support Organisations (ESOs) that already have relationships with founders and understand the markets they operate in.



“Because we’re deeply embedded in Nigeria’s startup ecosystem, we’re able to identify founders with strong potential long before they’re on the radar of traditional investors,” said Carolina Gideon-Krama, venture analyst at Africa Fintech Foundry.



The model was also used for the facility’s first investments in Ghana. In May, Village Capital [invested](https://techcabal.com/2026/05/06/village-capital-backs-two-ghanaian-startups-with-350000-form-latest-fund/) $200,000 in Rivia Clinics, a tech-enabled primary healthcare startup, and $150,000 in VDL Fulfilment, an e-commerce logistics platform. The facility has now invested in seven startups across Ghana and Nigeria, with additional investments planned in Nigeria and Tanzania.



_**True scale demands moving beyond surface-level integrations to robust execution. We’ve filtered the noise out of Moonshot 2026, optimising the conference strictly for high-calibre connections between startup founders, global financial operators, enterprise leaders and individuals rewiring Africa’s technical frameworks. [Get 20% off Early Bird tickets for a limited time](https://mainstack.com/p/moonshot-by-techcabal-2026/tickets).**_

![](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/07/IMG_4259-3-1-1024x581.jpg)





























## More from this Author



  - [![South African founder raises $1.67 million to make robots better at handling objects](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/11/Robotics-CEO-1-240x160.webp)](https://techcabal.com/2026/11/23/lupa-robotics-1-67-million-seed-raise/)



    [Startups](https://techcabal.com/category/startups/)



    [South African founder raises $1.67 million to make robots better at handling objects](https://techcabal.com/2026/11/23/lupa-robotics-1-67-million-seed-raise/)

  - [![Why First Circle Capital won’t back fintechs that treat AI as an afterthought](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/11/selma-240x160.webp)](https://techcabal.com/2026/11/23/first-circle-capital-ask-an-investor/)



    [Ask An Investor](https://techcabal.com/category/techcabal-columns/ask-an-investor/)



    [Why First Circle Capital won’t back fintechs that treat AI as an afterthought](https://techcabal.com/2026/11/23/first-circle-capital-ask-an-investor/)

  - [![👨🏿‍🚀TechCabal Daily – Kuda cuts jobs, again](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/11/greg-hirsch-letting-all-of-you-go-1.gif)](https://techcabal.com/2026/11/20/techcabal-daily-kuda-cuts-jobs-again/)



    [Newsletters](https://techcabal.com/category/newsletters/)



    [👨🏿‍🚀TechCabal Daily – Kuda cuts jobs, again](https://techcabal.com/2026/11/20/techcabal-daily-kuda-cuts-jobs-again/)


[![First Circle Capital closes $26 million fund to back early-stage African fintechs](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/11/Team-Photo-300x200.webp)](https://techcabal.com/2026/11/18/first-circle-capital-raises-26-million/)

[Funding](https://techcabal.com/category/startups/funding/)

[First Circle Capital closes $26 million fund to back early-stage African fintechs](https://techcabal.com/2026/11/18/first-circle-capital-raises-26-million/)

Opeyemi Kareem

\|

6 days ago

  - ## Read Next


    [![Banks, card networks raid Safaricom, Airtel and MTN for top talent](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/11/saf-alumni-1.webp)](https://techcabal.com/2026/11/24/banks-card-raid-safaricom-airtel-talent/) _Stanbic Kenya CEO Michael Mutiga, Absa Group personal and private banking CEO Sitoyo Lopokoiyit, and Visa East and Southern Africa head Esther Masese Waititu. Image source: TC Design_



    ## Read Next



    [Companies](https://techcabal.com/category/enterprise-policy/companies/)



    ### [Banks, card networks raid Safaricom, Airtel and MTN for top talent](https://techcabal.com/2026/11/24/banks-card-raid-safaricom-airtel-talent/)





    [Adonijah Ndege](https://techcabal.com/author/adonijah/)



    24th Nov, 2026


## Read more

- [![Meta’s privacy scandal leaves Kenya chasing the wrong defendants ](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/11/Mercy-Mutemi-Executive-Director-The-Oversight-Lab-1024x576.webp)](https://techcabal.com/2026/11/24/meta-and-sama-privacy-probe-kenya/) _Mercy Mutemi, Executive Director, The Oversight Lab. Image: BAKE_



[Analysis](https://techcabal.com/category/analysis/)



## [Meta’s privacy scandal leaves Kenya chasing the wrong defendants](https://techcabal.com/2026/11/24/meta-and-sama-privacy-probe-kenya/)







Kenn Abuya



24th Nov, 2026

- [![Banks, card networks raid Safaricom, Airtel and MTN for top talent](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/11/saf-alumni-1-1024x576.webp)](https://techcabal.com/2026/11/24/banks-card-raid-safaricom-airtel-talent/) _Stanbic Kenya CEO Michael Mutiga, Absa Group personal and private banking CEO Sitoyo Lopokoiyit, and Visa East and Southern Africa head Esther Masese Waititu. Image source: TC Design_



[Companies](https://techcabal.com/category/enterprise-policy/companies/)



## [Banks, card networks raid Safaricom, Airtel and MTN for top talent](https://techcabal.com/2026/11/24/banks-card-raid-safaricom-airtel-talent/)







Adonijah Ndege



24th Nov, 2026

- [![In the DRC, Wave’s next pricing test is the franc](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/11/54623364919_12dcce3c74_o-edited-1024x768.webp)](https://techcabal.com/2026/11/24/francophone-weekly-by-techcabal-049/) _A vegetable shop that accepts Wave mobile money in Dakar, Senegal. Image Source: Norfund._



[Francophone Weekly](https://techcabal.com/category/newsletters/francophone-weekly-by-techcabal/), [Newsletters](https://techcabal.com/category/newsletters/)



## [In the DRC, Wave’s next pricing test is the franc](https://techcabal.com/2026/11/24/francophone-weekly-by-techcabal-049/)







Lina Kacyem



24th Nov, 2026

- [![Nigeria wants to turn data protection into a 500,000-job pipeline](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/11/Dr-Vincent-Olatunji-data-protection-dpo-1024x681.webp)](https://techcabal.com/2026/11/24/nigeria-data-protection-500000-jobs/) _NDPC Commissioner, Vincent Olatunji. Image Source: Twitter/@ndpcngr_



[Enterprise & Policy](https://techcabal.com/category/enterprise-policy/)



## [Nigeria wants to turn data protection into a 500,000-job pipeline](https://techcabal.com/2026/11/24/nigeria-data-protection-500000-jobs/)





[Progress Godfrey](https://techcabal.com/author/progress/)

24th Nov, 2026

- [![Ericsson sees enterprise customers driving South Africa’s next 5G growth opportunity](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/11/Ngxola-new-1024x682.webp)](https://techcabal.com/2026/11/23/ericsson-sa-5g-growth-mines-ports/) _Siseko Ngxola, head of Ericsson South Africa, says enterprise connectivity, private 5G networks and AI could unlock new revenue streams for mobile operators as they seek to monetise their 5G investments. Image source: Ericsson_



[Telecoms](https://techcabal.com/category/enterprise-policy/telecoms/)



## [Ericsson sees enterprise customers driving South Africa’s next 5G growth opportunity](https://techcabal.com/2026/11/23/ericsson-sa-5g-growth-mines-ports/)







Phathisani Moyo



23rd Nov, 2026

- [![Mzansi’s power moves](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/11/cr1-1.webp)](https://techcabal.com/2026/11/23/mzansis-power-moves/) _South African President Cyril Ramaphosa with members of the South African delegation during a working visit to Silicon Valley in November 2026. Photo credit: SAnews.gov.za._



[TC Mzansi](https://techcabal.com/category/newsletters/tc-mzansi/), [Newsletters](https://techcabal.com/category/newsletters/)



## [Mzansi’s power moves](https://techcabal.com/2026/11/23/mzansis-power-moves/)







Phathisani Moyo



23rd Nov, 2026


×

Become an Insider to continue reading for free

![](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2026/09/tc-gate-general-img.png)

## The smartest people in African tech are TC Insiders.

Join other readers from across the continent.

Continue with Google

or

Company

Continue

![TechCabal](https://c76c7bbc41.mjedge.net/wp-content/themes/tc3.0/assets/img/tc-icon.png)

✉

## Check your email

We sent a secure sign-in link to

Open the link on this device to continue. The link expires in 10 minutes.

You can request another link in 5:00
Resend sign-in link

![TechCabal](https://c76c7bbc41.mjedge.net/wp-content/themes/tc3.0/assets/img/tc-icon.png)

## Check your email

Enter the 6 digit code sent to

Company

Incorrect code. Please try again.

Continue

Resend code in 40s
Resend code

![TechCabal](https://c76c7bbc41.mjedge.net/wp-content/themes/tc3.0/assets/img/tc-icon.png)

## What kind of stories are you interested in?

Choose the topics you'd like to see.

Analysis🤖 Artificial IntelligenceBattlefieldBlogBuilding from Ground UpCabalCollectionsColumnsCorrectionsEast AfricaEnterprise & Policy📅 EventsExclusiveExplainersFactsheetFeaturesFructoseFundamentalsGuest PostKenyaLetter from the EditorLife & WorkLinked ListMoneyMoonshotMoonshot ConversationsNews📧 Newsletters💬 OpinionPress ReleasePress RoomQuick FireQuiz📊 ReportsResearchSouth AfricaSouthern Africa🚀 StartupsTC InsightsTech Like I'm FiveUncategorizedVideoVideosWeekly

Done
Skip

## Get our newsletter delivered straight to your inbox.

Techcabal keeps you in the loop on the latest updates in the African Tech ecosystem.

or

Company

Become a TC Insider and get access to member-only content for free. Continue